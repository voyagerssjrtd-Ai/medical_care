from services.workflow import app
import json

def calling_langgarph(user_input):
    result = app.invoke({
        "query": user_input
    })

    # def clean_llm_output(result: dict) -> str:
    #     filtered = {
    #         k: v for k, v in result.items()
    #         if v not in (None, "", [], {})
    #     }
    #     return json.dumps(filtered, ensure_ascii=False, indent=2)

    # json = clean_llm_output(result)
    # print(json)
    
    # if(result["intent"]) == "appointment":
    #     return result
    # else :
    #     return result["output"]

    # print(json)
    # print("\n====== AGENT OUTPUT ======")
    # print(result["intent"])
    if "error" in result:
        print(result["error"])
    if "kind" in result:
        print(result["kind"])
    if "status" in result:
        print(result["status"])
    if "alternatives" in result:
        print(result["alternatives"])
    # print(result["output"])
    # print("==========================================\n")
    return result["output"]