"""HTTP API for the AI-powered patient triage and clinician tools."""

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import sqlite3
from pathlib import Path

from .core.config import get_settings
from .core.logging import configure_logging
from .core.errors import (
    ExternalServiceError,
    external_service_error_handler,
    validation_exception_handler,
)
from fastapi.exceptions import RequestValidationError
from .api import files as files_api
from .api import appointments as appointments_api
from .api import guardrails as guardrails_api
from .api import workflow as workflow_api
from .services.triage_service import run_triage
from .models.triage import SymptomTriageRequest, SymptomTriageResponse

configure_logging()
settings = get_settings()

app = FastAPI(title="AI Patient Triage API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin] if hasattr(settings, "frontend_origin") else ["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_exception_handler(ExternalServiceError, external_service_error_handler)
app.add_exception_handler(RequestValidationError, validation_exception_handler)


class ChatRequest(BaseModel):
    """Generic chat payload used by the existing /chat endpoint."""

    message: str


# --- helper for DB connection ---
DB_PATH = Path(__file__).resolve().parent.parent / "data" / "inventory.db"

def get_db_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# --- Helper: get current user type and email (stub, replace with real auth) ---
def get_current_user(request: Request):
    # In production, use real authentication/session/cookie/JWT
    # Here, use query params for demo: ?user_type=clinician or ?user_type=patient&email=...
    user_type = request.query_params.get("user_type", "patient")
    email = request.query_params.get("email")
    return user_type, email

# --------------- Routers -----------------

app.include_router(files_api.router)
app.include_router(appointments_api.router)
app.include_router(guardrails_api.router)
app.include_router(workflow_api.router)


# --------------- CHAT / LLM -----------------
@app.post("/chat")
async def chat(req: ChatRequest):
    """Legacy chat endpoint.

    For now, this simply calls the triage service and returns the
    raw model output as a plain text "response" field so the
    existing frontend can keep working.
    """

    triage_res = run_triage(symptoms=req.message, patient_email=None)
    return {"response": triage_res.raw_model_output}


# --------------- SYMPTOM TRIAGE (production-facing) -----------------
@app.post("/triage", response_model=SymptomTriageResponse)
async def triage(req: SymptomTriageRequest) -> SymptomTriageResponse:
    """Main AI triage endpoint.

    Delegates to the `run_triage` service which coordinates RAG + EHR
    context and converts the result into a normalized response model.
    """

    return run_triage(
        symptoms=req.symptoms,
        patient_email=req.patient_email,
        additional_context=req.additional_context,
    )

# --------------- PATIENT SUMMARY (already used by Chat UI) -----------------
@app.get("/patient/{email}")
def get_patient_summary(email: str):
    conn = get_db_conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM patients WHERE email = ?", (email,))
        row = cur.fetchone()
    finally:
        conn.close()

    if not row:
        raise HTTPException(status_code=404, detail="Patient not found")

    return dict(row)

# --------------- CLINICIAN OVERVIEW (NEW) -----------------
@app.get("/clinician/overview")
def clinician_overview():
    """
    Overview data for the clinician dashboard.

    Uses the existing `patients` table, which already stores:
    - demographics (name, email, age, gender, mrn, primary_doctor, last_visit)
    - vitals (hr, bp, temp, spo2)
    - appointments (appointment_title, appointment_date, appointment_location)
    - care plan (active_conditions, plan, next_steps, etc.)
    """
    conn = get_db_conn()
    try:
        cur = conn.cursor()
        # Pull key fields from the patients table
        cur.execute(
    """
    SELECT
        id,
        name,
        email,
        age,
        gender,
        mrn,
        primary_doctor,
        last_visit,

        hr,
        bp,
        temp,
        spo2,

        COALESCE(active_conditions, '') AS active_conditions,
        COALESCE(appointment_title, '') AS appointment_title,
        COALESCE(appointment_date, '') AS appointment_date,
        COALESCE(appointment_location, '') AS appointment_location,
        COALESCE(plan, '') AS plan,
        COALESCE(next_steps, '') AS next_steps
    FROM patients
    """
)
        rows = cur.fetchall()
    finally:
        conn.close()

    patients = [dict(r) for r in rows]

    # ---------- Build triage queue from patient records ----------
    triage_queue = []
    for p in patients:
        reason = p.get("active_conditions") or p.get("plan") or "Symptom update"
        txt = (reason or "").lower()

        # Simple keyword-based severity for demo
        if any(k in txt for k in ["chest", "breath", "shortness of breath", "severe"]):
            severity = "High"
        elif any(k in txt for k in ["fever", "cough", "infection", "pain"]):
            severity = "Medium"
        else:
            severity = "Low"

        triage_queue.append(
            {
                "id": f"T-{p['id']}",
                "name": p["name"],
                "email": p["email"],
                "mrn": p["mrn"],  
                "severity": severity,
                "reason": reason,
                # For now, a static placeholder; you can add created_at to patients later
                "waiting": "10 min",
            }
        )

    # ---------- Build follow-up items from appointments / next_steps ----------
    followups = []
    for p in patients:
        has_appointment = bool(p.get("appointment_date"))
        has_next_steps = bool(p.get("next_steps"))

        if not (has_appointment or has_next_steps):
            continue

        followups.append(
            {
                "id": f"F-{p['id']}",
                "name": p["name"],
                "type": p.get("appointment_title") or "Care plan follow-up",
                # combine appointment date + location or fall back to next_steps text
                "due": (
                    f"{p['appointment_date']} @ {p['appointment_location']}"
                    if p.get("appointment_date")
                    else p.get("next_steps") or "No date set"
                ),
            }
        )

    # ---------- Aggregate triage stats ----------
    high_risk = sum(1 for t in triage_queue if t["severity"] == "High")
    awaiting_review = len(triage_queue)  # can be refined later
    followups_today = len(followups)     # also can be refined by date

    triage_stats = {
        "open_cases": len(triage_queue),
        "high_risk": high_risk,
        "awaiting_review": awaiting_review,
        "followups_today": followups_today,
    }

    # ---------- Stub: recent AI sessions (later you can log chats here) ----------
    ai_sessions = [
        {
            "id": "S-9001",
            "title": "Chest pain triage",
            "when": "10 min ago",
            "status": "Completed",
        },
        {
            "id": "S-9002",
            "title": "Fever & cough triage",
            "when": "35 min ago",
            "status": "In review",
        },
    ]

    # ---------- Stub: system health metrics ----------
    system_health = {
        "llm_latency_ms": 830,
        "api_error_rate": "0.9%",
        "active_agents": 3,
        "ehr_latency_ms": 210,
    }

    return {
        "triage_stats": triage_stats,
        "triage_queue": triage_queue,
        "followups": followups,
        "ai_sessions": ai_sessions,
        "system_health": system_health,
    }

@app.get("/patients")
def get_patients(request: Request):
    user_type, email = get_current_user(request)
    conn = get_db_conn()
    try:
        cur = conn.cursor()
        if user_type == "clinician":
            cur.execute("SELECT * FROM patients")
            rows = cur.fetchall()
            return [dict(r) for r in rows]
        elif user_type == "patient" and email:
            cur.execute("SELECT * FROM patients WHERE email = ?", (email,))
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Patient not found")
            return dict(row)
        else:
            raise HTTPException(status_code=400, detail="Invalid user context")
    finally:
        conn.close()


@app.get("/")
def root():
    return {"status": "running"}

# ---------------- AUTH: LOGIN -----------------

class LoginRequest(BaseModel):
    email: str
    password: str
    role: str   # "patient" or "clinician"

class LoginResponse(BaseModel):
    name: str
    email: str
    role: str
    patient_id: int | None = None
    clinician_id: int | None = None
    token: str

@app.post("/auth/login", response_model=LoginResponse)
def login(req: LoginRequest):
    conn = get_db_conn()
    try:
        cur = conn.cursor()

        if req.role == "patient":
            cur.execute("SELECT id, name, email, password FROM patients WHERE email = ?", (req.email,))
            row = cur.fetchone()
            if not row or row["password"] != req.password:
                raise HTTPException(status_code=401, detail="Invalid credentials")

            token = f"patient-{row['id']}"

            return LoginResponse(
                name=row["name"],
                email=row["email"],
                role="patient",
                patient_id=row["id"],
                clinician_id=None,
                token=token,
            )

        elif req.role == "clinician":
            cur.execute("SELECT id, name, email, password FROM clinicians WHERE email = ?", (req.email,))
            row = cur.fetchone()
            if not row or row["password"] != req.password:
                raise HTTPException(status_code=401, detail="Invalid credentials")

            token = f"clinician-{row['id']}"

            return LoginResponse(
                name=row["name"],
                email=row["email"],
                role="clinician",
                patient_id=None,
                clinician_id=row["id"],
                token=token,
            )

        raise HTTPException(status_code=400, detail="Invalid role")

    finally:
        conn.close()

# ---------------- CLINICIAN: CREATE TRIAGE SESSION -----------------

class CreateSessionRequest(BaseModel):
    patient_id: int

class SessionResponse(BaseModel):
    session_id: int

@app.post("/clinician/triage-sessions", response_model=SessionResponse)
def clinician_create_triage_session(req: CreateSessionRequest):
    from datetime import datetime

    conn = get_db_conn()
    try:
        cur = conn.cursor()
        now = datetime.utcnow().isoformat()
        cur.execute(
            """
            INSERT INTO triage_sessions (patient_id, created_at, created_by, status)
            VALUES (?, ?, 'clinician', 'draft')
            """,
            (req.patient_id, now),
        )
        session_id = cur.lastrowid
        conn.commit()
        return SessionResponse(session_id=session_id)
    finally:
        conn.close()


# ---------------- PATIENT: CREATE TRIAGE SESSION -----------------

@app.post("/patient/triage-sessions", response_model=SessionResponse)
def patient_create_triage_session(request: Request):
    from datetime import datetime
    
    user_type, email = get_current_user(request)
    if user_type != "patient" or not email:
        raise HTTPException(status_code=403, detail="Patients only")

    conn = get_db_conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT id FROM patients WHERE email = ?", (email,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Patient not found")
        
        patient_id = row["id"]
        now = datetime.utcnow().isoformat()

        cur.execute(
            """
            INSERT INTO triage_sessions (patient_id, created_at, created_by, status)
            VALUES (?, ?, 'patient', 'draft')
            """,
            (patient_id, now),
        )
        session_id = cur.lastrowid
        conn.commit()
        return SessionResponse(session_id=session_id)
    finally:
        conn.close()

# ---------------- TRIAGE MESSAGE ENDPOINT (core chat logic) -----------------

class TriageMessageRequest(BaseModel):
    sender_type: str  # 'patient' | 'clinician'
    text: str

class TriageMessageResponse(BaseModel):
    ai_reply: str
    triage_level: str | None = None
    followup_plan: str | None = None


@app.post("/triage-sessions/{session_id}/message", response_model=TriageMessageResponse)
async def triage_message(session_id: int, req: TriageMessageRequest):
    from datetime import datetime

    # ---- Get session + patient ----
    conn = get_db_conn()
    try:
        cur = conn.cursor()
        cur.execute(
            """
            SELECT ts.*, p.email
            FROM triage_sessions ts
            JOIN patients p ON p.id = ts.patient_id
            WHERE ts.id = ?
            """,
            (session_id,),
        )
        row = cur.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail="Session not found")

        patient_email = row["email"]

        # Save user message
        now = datetime.utcnow().isoformat()
        cur.execute(
            """
            INSERT INTO triage_messages (session_id, sender_type, message_text, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (session_id, req.sender_type, req.text, now),
        )
        conn.commit()

    finally:
        conn.close()

    # ---- AI: Run full triage pipeline ----
    triage_result = run_triage(
        symptoms=req.text,
        patient_email=patient_email,
        additional_context=None,
    )

    # These attribute names may differ based on your SymptomTriageResponse class
    ai_reply = getattr(triage_result, "ai_response", None) or triage_result.summary
    triage_level = triage_result.triage_level
    followup_plan = triage_result.followup_plan

    # ---- Store AI reply ----
    conn = get_db_conn()
    try:
        cur = conn.cursor()
        now = datetime.utcnow().isoformat()

        cur.execute(
            """
            INSERT INTO triage_messages (session_id, sender_type, message_text, created_at)
            VALUES (?, 'ai', ?, ?)
            """,
            (session_id, ai_reply, now),
        )

        cur.execute(
            """
            UPDATE triage_sessions
            SET triage_level = ?, ai_summary = ?, status = 'awaiting_review'
            WHERE id = ?
            """,
            (triage_level, followup_plan, session_id),
        )

        conn.commit()
    finally:
        conn.close()

    return TriageMessageResponse(
        ai_reply=ai_reply,
        triage_level=triage_level,
        followup_plan=followup_plan,
    )

# ---------------- CLINICIAN: GET TRIAGE SESSION DETAILS -----------------

@app.get("/clinician/triage-sessions/{session_id}")
def get_triage_session_details(session_id: int):
    conn = get_db_conn()
    try:
        cur = conn.cursor()

        cur.execute(
            """
            SELECT ts.*, p.name AS patient_name, p.mrn, p.active_conditions
            FROM triage_sessions ts
            JOIN patients p ON p.id = ts.patient_id
            WHERE ts.id = ?
            """,
            (session_id,),
        )
        session_row = cur.fetchone()

        if not session_row:
            raise HTTPException(status_code=404, detail="Session not found")

        cur.execute(
            """
            SELECT sender_type, message_text, created_at
            FROM triage_messages
            WHERE session_id = ?
            ORDER BY created_at ASC
            """,
            (session_id,),
        )

        messages = [dict(r) for r in cur.fetchall()]
        return {
            "session": dict(session_row),
            "messages": messages
        }

    finally:
        conn.close()
