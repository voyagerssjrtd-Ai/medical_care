from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from pydantic import ValidationError
import logging


logger = logging.getLogger(__name__)


class ExternalServiceError(Exception):
    """Raised when an upstream service (LLM, DB, external API) fails."""

    def __init__(self, service: str, detail: str):
        self.service = service
        self.detail = detail
        super().__init__(f"{service} failed: {detail}")


async def external_service_error_handler(
    _request: Request, exc: ExternalServiceError
) -> JSONResponse:
    logger.error("External service error", extra={"service": exc.service, "detail": exc.detail})
    return JSONResponse(
        status_code=502,
        content={
            "error": "external_service_error",
            "service": exc.service,
            "detail": exc.detail,
        },
    )


async def validation_exception_handler(
    _request: Request, exc: RequestValidationError | ValidationError
) -> JSONResponse:
    logger.warning("Validation error", extra={"errors": exc.errors()})
    return JSONResponse(
        status_code=422,
        content={"error": "validation_error", "details": exc.errors()},
    )
