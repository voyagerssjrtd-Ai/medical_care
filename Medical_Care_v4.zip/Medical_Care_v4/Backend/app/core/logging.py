import logging
import sys


def configure_logging() -> None:
    """Configure basic structured logging for the backend service."""

    root = logging.getLogger()
    if root.handlers:
        # Avoid reconfiguring if already set up
        return

    root.setLevel(logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s [%(name)s] %(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)

    root.addHandler(handler)
