"""Pydantic models for the AI triage backend."""
