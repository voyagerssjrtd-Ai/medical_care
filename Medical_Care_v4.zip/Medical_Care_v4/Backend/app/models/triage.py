from typing import List, Optional
from pydantic import BaseModel


class FollowUpPlan(BaseModel):
    """
    Normalized triage plan returned by the triage_service.
    """
    triage_level: str                    # "low/self-care" | "medium" | "high/urgent" | "emergency"
    recommendations: List[str]           # bullet-point actions / advice
    follow_up_timeline: str              # free-text timing guidance
    escalation_warning: str              # safety warning text
    # you can add more fields later if needed, e.g. `reasoning: Optional[str] = None`


class SymptomTriageRequest(BaseModel):
    """
    Request body for the /triage endpoint.
    Used in app.main: `@app.post("/triage", response_model=SymptomTriageResponse)`
    """
    symptoms: str
    patient_email: Optional[str] = None
    additional_context: Optional[str] = None


class SymptomTriageResponse(BaseModel):
    """
    Response model from triage_service.run_triage, used by both
    /triage and the workflow service.
    """
    summary: str
    follow_up_plan: FollowUpPlan
    raw_model_output: str
    intent: Optional[str] = None
    target_agent: Optional[str] = None
