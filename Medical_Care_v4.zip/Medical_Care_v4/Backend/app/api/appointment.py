from fastapi import APIRouter

from ..services.appointment_service import (
    AppointmentRequest,
    AppointmentResponse,
    book_appointment,
)


router = APIRouter(prefix="/appointment", tags=["appointment"])


@router.post("/book", response_model=AppointmentResponse)
async def book(req: AppointmentRequest) -> AppointmentResponse:
    """Book an appointment using the appointment agent.

    For now this returns a placeholder message but is fully wired
    and logged; you can later replace the agent logic with a real
    scheduler without changing this endpoint.
    """

    return book_appointment(req)
