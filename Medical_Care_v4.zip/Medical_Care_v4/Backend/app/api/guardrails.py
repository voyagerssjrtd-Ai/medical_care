from fastapi import APIRouter

from ..services.guardrails_service import (
    GuardrailsRequest,
    GuardrailsResponse,
    run_guardrails,
)


router = APIRouter(prefix="/guardrails", tags=["guardrails"])


@router.post("/validate", response_model=GuardrailsResponse)
async def validate(req: GuardrailsRequest) -> GuardrailsResponse:
    """Validate a user input string using basic guardrails."""

    return run_guardrails(req.text)
