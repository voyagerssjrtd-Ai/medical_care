# app/api/appointments.py
from fastapi import APIRouter
from ..services.appointment_service import (
    AppointmentRequest,
    AppointmentResponse,
    book_appointment,
)

router = APIRouter(prefix="/appointments", tags=["appointments"])


@router.post("/book", response_model=AppointmentResponse)
async def book_appointment_api(req: AppointmentRequest) -> AppointmentResponse:
    """
    Book an appointment via the appointment agent.

    Example body:
    {
      "patient_id": "P001",
      "symptoms": "Chest pain when walking stairs",
      "triage_level": "high/urgent",
      "preferred_times": ["2025-12-03T10:00"]
    }
    """
    return book_appointment(req)
