from fastapi import APIRouter, File, UploadFile
from typing import List
from pathlib import Path

router = APIRouter(prefix="/files", tags=["files"])

SAVE_DIR = Path(__file__).resolve().parents[3] / "database" / "legacy" / "savedFiles"
SAVE_DIR.mkdir(parents=True, exist_ok=True)


@router.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    """Upload a single document to the legacy savedFiles folder."""
    target = SAVE_DIR / file.filename.replace(" ", "_")
    with target.open("wb") as f:
        f.write(await file.read())
    return {"status": "ok", "filename": target.name}


@router.post("/upload/batch")
async def upload_multiple_documents(files: List[UploadFile] = File(...)):
    """Upload multiple documents in one request."""
    saved: list[str] = []
    for file in files:
        target = SAVE_DIR / file.filename.replace(" ", "_")
        with target.open("wb") as f:
            f.write(await file.read())
        saved.append(target.name)
    return {"status": "ok", "saved": saved}
