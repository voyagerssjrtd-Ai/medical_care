import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[1] / "data" / "inventory.db"


def get_db():
    return sqlite3.connect(DB_PATH)


import sqlite3
from pathlib import Path

# This resolves to the "Backend" folder
BASE_DIR = Path(__file__).resolve().parents[2]
DB_PATH = BASE_DIR / "data" / "inventory.db"


def get_db():
    # Ensure the folder exists
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    # Connect with row factory so we can return dicts easily
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def get_patient_by_mrn(mrn: str):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM patients WHERE mrn = ?", (mrn,))
    row = cur.fetchone()
    conn.close()
    if row is None:
        return None
    return dict(row)

    cols = [
        "id", "email", "name", "age", "gender", "mrn", "primary_doctor",
        "last_visit", "hr", "bp", "temp", "spo2",
        "appointment_title", "appointment_date", "appointment_location",
        "medication1", "medication1_dose", "medication1_freq",
        "medication2", "medication2_dose", "medication2_freq",
        "active_conditions", "plan", "next_steps"
    ]

    return dict(zip(cols, row))
