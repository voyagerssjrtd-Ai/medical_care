import logging

from pydantic import BaseModel

from agents.guardrails_agent import parse_intent, validate_input


logger = logging.getLogger(__name__)


class GuardrailsRequest(BaseModel):
    text: str


class GuardrailsResponse(BaseModel):
    ok: bool
    intent: str
    message: str


def run_guardrails(text: str) -> GuardrailsResponse:
    """Run basic guardrails checks and return a structured result."""

    try:
        validate_input(text)
    except Exception as e:  # noqa: BLE001 - we want to surface any guardrails error
        logger.warning(
            "guardrails_forbidden",
            extra={"text_preview": text[:100]},
        )
        return GuardrailsResponse(ok=False, intent="blocked", message=str(e))

    intent = parse_intent(text)
    logger.info("guardrails_passed", extra={"intent": intent})
    return GuardrailsResponse(ok=True, intent=intent, message="Input is allowed")
