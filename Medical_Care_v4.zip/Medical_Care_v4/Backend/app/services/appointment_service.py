import logging
from typing import List, Optional

from pydantic import BaseModel

from agents.appointment_agent import (
    appointment_book_agent,
    AppointmentState,
)

logger = logging.getLogger(__name__)


class AppointmentRequest(BaseModel):
    patient_id: str
    symptoms: Optional[str] = None
    triage_level: Optional[str] = None
    preferred_times: Optional[List[str]] = None


class AppointmentResponse(BaseModel):
    # High-level status for the UI / workflow
    status: str                     # "confirmed" | "unavailable" | "error" | "none"
    # Human-readable explanation from the agent
    details: str
    # Optional extra data from the agent
    slot: Optional[str] = None      # e.g. "2025-12-02T10:30"
    alternatives: Optional[str] = None  # JSON/text with alternative slots, if any


def book_appointment(req: AppointmentRequest) -> AppointmentResponse:
    """
    Invoke the LLM-driven appointment agent and convert its state
    into a stable response model for the API / frontend.
    """

    state: AppointmentState = {
        "patient_id": req.patient_id,
        "symptoms": req.symptoms or "",
        "triage_level": req.triage_level or "",
        "preferred_times": req.preferred_times or [],
    }

    logger.info(
        "appointment_book_started",
        extra={
            "patient_id": req.patient_id,
            "triage_level": req.triage_level or "",
        },
    )

    # This calls into your routing logic + sub-agents
    # (disease_appoint_agent, doctor_appoint_agent, lab_appoint_agent, service_appoint_agent, etc.)
    state = appointment_book_agent(state)

    logger.info(
        "appointment_book_completed",
        extra={
            "patient_id": req.patient_id,
            "status": state.get("status", "none"),
        },
    )

    # Map the agent's state -> clean response for the workflow + frontend
    return AppointmentResponse(
        status=state.get("status", "none"),
        details=state.get("output", "No output produced"),
        slot=state.get("booked_slot"),
        alternatives=state.get("alternatives"),
    )
    state = appointment_book_agent(state)
    logger.info("appointment_state_after_agent", extra={"state": state})