# Backend/app/services/triage_service.py

from typing import Dict, Any
import logging

from ..models.triage import FollowUpPlan, SymptomTriageResponse
from agents.chat_agent import chat_query_agent

logger = logging.getLogger(__name__)


def run_triage(
    symptoms: str,
    patient_email: str | None = None,
    additional_context: str | None = None,
) -> SymptomTriageResponse:
    """Use chat_query_agent + simple parsing to create a normalized triage object."""

    logger.info(
        "Starting triage",
        extra={"symptoms_preview": symptoms[:200], "patient_email": patient_email},
    )

    state: Dict[str, Any] = {"query": symptoms}
    state = chat_query_agent(state)
    raw_output: str = state.get("output", "No response produced")

    lowered = raw_output.lower()

    # --- 1) Try to parse explicit Triage Level line first ---
    triage_level = None
    for line in raw_output.splitlines():
        low = line.strip().lower()
        if low.startswith("- **triage level**") or low.startswith("**triage level**"):
            parts = line.split(":", 1)
            if len(parts) == 2:
                triage_level = parts[1].strip()
            break

    # --- 2) Fallback: scan text ---
    if triage_level:
        lvl_low = triage_level.lower()
        if "emergency" in lvl_low:
            triage_level = "emergency"
        elif "high" in lvl_low or "urgent" in lvl_low:
            triage_level = "high/urgent"
        elif "medium" in lvl_low:
            triage_level = "medium"
        else:
            triage_level = "low/self-care"
    else:
        if "emergency" in lowered:
            triage_level = "emergency"
        elif "high" in lowered or "urgent" in lowered:
            triage_level = "high/urgent"
        elif "medium" in lowered:
            triage_level = "medium"
        else:
            triage_level = "low/self-care"

    reasoning_text: str | None = None
    urgent_eval: str | None = None
    patient_actions: list[str] = []
    clinician_tasks: list[str] = []
    recommendations: list[str] = []

    for line in raw_output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue

        low = stripped.lower()

        # parse the structured bullets we asked the LLM to produce
        if low.startswith("- **reasoning**"):
            parts = stripped.split(":", 1)
            if len(parts) == 2:
                reasoning_text = parts[1].strip()
        elif low.startswith("- **urgent evaluation needed**"):
            parts = stripped.split(":", 1)
            if len(parts) == 2:
                urgent_eval = parts[1].strip()
        elif low.startswith("- **patient actions**"):
            parts = stripped.split(":", 1)
            if len(parts) == 2:
                patient_actions.append(parts[1].strip())
        elif low.startswith("- **clinician tasks**"):
            parts = stripped.split(":", 1)
            if len(parts) == 2:
                clinician_tasks.append(parts[1].strip())

        # generic bullets → keep as recommendations
        if stripped.lstrip().startswith(("-", "*", "•")):
            recommendations.append(stripped.lstrip("-*• ").strip())

    if not recommendations:
        recommendations = [raw_output]

    if not reasoning_text:
        reasoning_text = recommendations[0] if recommendations else raw_output

    follow_up_plan = FollowUpPlan(
        triage_level=triage_level,
        recommendations=recommendations,
        follow_up_timeline="See full text for suggested timing.",
        escalation_warning=(
            "If symptoms worsen, new red-flag signs appear, or the patient is worried, "
            "they should seek urgent in-person evaluation."
        ),
        reasoning=reasoning_text,
        urgent_evaluation=urgent_eval,
        patient_actions=patient_actions or None,
        clinician_tasks=clinician_tasks or None,
    )

    logger.info(
        "Triage completed",
        extra={"triage_level": triage_level, "recommendations_count": len(recommendations)},
    )

    return SymptomTriageResponse(
        summary=raw_output,          # full formatted answer from LLM
        follow_up_plan=follow_up_plan,
        raw_model_output=raw_output,
        intent=state.get("intent"),
        target_agent=state.get("target_agent"),
    )
