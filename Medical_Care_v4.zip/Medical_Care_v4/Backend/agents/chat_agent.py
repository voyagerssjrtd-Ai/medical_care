# Backend/agents/chat_agent.py

from services.azure_llm import getMassGpt
from document_loader.loader import load_txts  # if you still use TXT docs
from services.chunking import getRetriever
from app.services.db_service import get_patient_by_mrn

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough


retriever = None
llm = getMassGpt()


def db_row_to_text(p: dict, prefix: str = "- "):
    """Convert a patients row (dict from SQLite) into a list of human-readable lines."""
    lines = []

    def nice_key(k: str) -> str:
        return k.replace("_", " ").title()

    for key, value in p.items():
        if value in (None, "", "null"):
            continue
        lines.append(f"{prefix}{nice_key(key)}: {value}")

    return lines


def chat_query_agent(state: dict) -> dict:
    """RAG-powered agent that answers clinical queries using docs + EHR."""

    global retriever

    user_query = state["query"]

    # --- 1) Resolve patient from MRN in the query (e.g. P001, P002) ---
    import re
    mrn_match = re.search(r"\bP\d{3}\b", user_query)

    patient_record_json = None
    if mrn_match:
        mrn = mrn_match.group(0)
        patient_record_json = get_patient_by_mrn(mrn)

    # ⚠️ No fallback to “first patient”; if we cannot resolve, we say so
    if patient_record_json:
        patient_record_text = db_row_to_text(patient_record_json)
        patient_record = "Patient Past Record:\n" + "\n".join(patient_record_text)
    else:
        patient_record = "No past record found."

    # --- 2) Build a strict RAG prompt with vitals / comorbidities emphasis ---
    qa_prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "You are a careful clinical triage assistant. "
                "You MUST use ONLY the information from the provided context and the patient's record. "
                "If you are not confident, assign a safer (higher) triage level and be explicit about uncertainty.",
            ),
            (
                "human",
                '''You are given the patient's past medical record (including vitals and comorbidities)
and the retrieved clinical context from reference documents.

Context (retrieved from vector database):
{context}

Patient Past Record:
{patient_record}

Current patient query / symptom:
{question}

You must reason like a cautious clinician:

- Pay attention to: chest pain, shortness of breath, neurologic symptoms, high fever, low SpO₂, very high/low heart rate, very abnormal blood pressure, pregnancy, age > 65, diabetes, heart disease, COPD/asthma, cancer, immunosuppression.
- If any life-threatening symptom or red-flag is possible, you MUST label triage as **Emergency**.
- If you are uncertain but risk could be significant, choose **High** rather than Medium/Low.

CRITICAL: Your response MUST follow EXACTLY this structure (no extra sections):

- **Triage Level**: [Low / Medium / High / Emergency]
- **Reasoning**: [Explain why this triage level is assigned, referencing specific vitals, comorbidities, and symptoms]
- **Urgent Evaluation Needed**: [Yes/No; specify tests or setting, e.g. "Yes - ER now", "Yes - clinic within 24h"]
- **Patient Actions**: [What the patient should do next, in 1-2 sentences]
- **Clinician Tasks**: [Specific tasks the clinician should perform, e.g. tests, monitoring, referrals]
- **Disclaimer**: [Standard medical disclaimer: this is not a diagnosis, seek in-person care if worried]

Do NOT invent facts not present in the record or context.
If the context and past record do not contain enough information, explicitly say that
your recommendation is based on limited information and choose the safer triage level.

Now, answer for the current patient and query using EXACTLY this format.
''',
            ),
        ]
    )

    # --- 3) Initialise retriever lazily ---
    if retriever is None:
        retriever = getRetriever()

    rag_chain = (
        {
            "context": retriever,
            "patient_record": lambda _: patient_record,
            "question": RunnablePassthrough(),
        }
        | qa_prompt
        | llm
    )

    resp = rag_chain.invoke(user_query)
    state["output"] = resp.content
    return state
