from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_triage_basic():
    payload = {"symptoms": "fever and cough", "patient_email": None}
    res = client.post("/triage", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert "follow_up_plan" in data
    assert data["follow_up_plan"]["triage_level"]


def test_triage_validation_error():
    # Missing required "symptoms" should trigger validation error
    res = client.post("/triage", json={})
    assert res.status_code in (400, 422)
