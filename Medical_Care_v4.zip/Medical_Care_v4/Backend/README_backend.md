# Backend Service

This directory contains the FastAPI backend for the **AI‑Driven Patient Symptom Triage and Follow‑up Planner**.

## 1. Prerequisites

- Python 3.10+
- pip
- A valid API key and access for your LLM provider (OpenAI / Azure OpenAI), configured via environment variables.

## 2. Install dependencies

From the repository root (`Medical_Care/`):

```powershell
cd "C:\path\to\Medical_Care"
pip install -r Backend/requirements.txt
```

## 3. Configure environment

Create a `.env` file in the repo root or export environment variables required by `azure_llm.py` and `Backend/app/core/config.py`, for example:

- `OPENAI_API_KEY` **or** the Azure equivalents used in `getMassGpt`.
- Any base URL / deployment name variables your environment expects.

Check `azure_llm.py` for the exact variable names your environment uses.

## 4. Run the backend

From the repository root:

```powershell
cd "C:\path\to\Medical_Care"
python -m uvicorn Backend.app.main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at:

- Swagger UI: http://localhost:8000/docs
- Root health: http://localhost:8000/

## 5. Project structure (backend)

- `Backend/app/main.py` – FastAPI app entrypoint and HTTP routes (`/chat`, `/triage`, patient & clinician endpoints).
- `Backend/app/core/` – configuration, logging, and error handling.
- `Backend/app/models/` – Pydantic models (e.g. triage request/response types).
- `Backend/app/services/` – business logic, e.g. `triage_service.run_triage`.
- `Backend/app/api/` – additional routers (e.g. file upload endpoints).
- `Backend/agents/` – modular agents (router, SQL, DB, formatter, LLM, chat/RAG).
- `Backend/graph/` – LangGraph state and routing graph wiring agents together.
- `Backend/config/` – configuration files like `router_rules.yaml` and prompts.
- `database/` (at repo root) – text and JSON data used by the RAG components.

## 6. Notes

- The backend assumes it is run from the **repository root** so that imports like `Backend.app.main` and data paths under `database/` resolve correctly.
- All hard-coded absolute paths have been removed in favor of paths relative to the repo.
- If you see an `openai.PermissionDeniedError: RBAC: access denied`, that indicates an issue with your LLM credentials or project permissions, not the backend code itself.
