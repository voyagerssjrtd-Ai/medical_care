CREATE TABLE IF NOT EXISTS patients (
    email TEXT PRIMARY KEY,
    name TEXT,
    age INTEGER,
    gender TEXT,
    mrn TEXT,
    primary_doctor TEXT,
    last_visit TEXT,

    hr INTEGER,
    bp TEXT,
    temp REAL,
    spo2 INTEGER,

    appointment_title TEXT,
    appointment_date TEXT,
    appointment_location TEXT,

    medication1 TEXT,
    medication1_dose TEXT,
    medication1_freq TEXT,

    medication2 TEXT,
    medication2_dose TEXT,
    medication2_freq TEXT,

    active_conditions TEXT,
    plan TEXT,
    next_steps TEXT
);
