-- Backend/db/sqlite_init.sql

-- Core patient table (matches seed_patients.py)
CREATE TABLE IF NOT EXISTS patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    name TEXT,
    age INTEGER,
    gender TEXT,
    mrn TEXT,
    primary_doctor TEXT,
    last_visit TEXT,

    hr INTEGER,
    bp TEXT,
    temp REAL,
    spo2 INTEGER,

    appointment_title TEXT,
    appointment_date TEXT,
    appointment_location TEXT,

    medication1 TEXT,
    medication1_dose TEXT,
    medication1_freq TEXT,

    medication2 TEXT,
    medication2_dose TEXT,
    medication2_freq TEXT,

    active_conditions TEXT,
    plan TEXT,
    next_steps TEXT
);

-- Clinicians (simple for now, we’ll seed manually or via a small script)
CREATE TABLE IF NOT EXISTS clinicians (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    specialty TEXT
);

-- Triage session metadata
CREATE TABLE IF NOT EXISTS triage_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    created_by TEXT NOT NULL,  -- 'patient' | 'clinician'
    triage_level TEXT,         -- 'Low' | 'Medium' | 'High'
    ai_summary TEXT,
    status TEXT DEFAULT 'draft',
    FOREIGN KEY(patient_id) REFERENCES patients(id)
);

-- Conversation messages inside a triage session
CREATE TABLE IF NOT EXISTS triage_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    sender_type TEXT NOT NULL,  -- 'patient' | 'clinician' | 'ai'
    message_text TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES triage_sessions(id)
);

-- Planned follow-ups linked to a triage session
CREATE TABLE IF NOT EXISTS followup_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    plan_text TEXT NOT NULL,
    next_review_date TEXT,
    status TEXT DEFAULT 'planned',
    FOREIGN KEY(session_id) REFERENCES triage_sessions(id)
);
