import sqlite3

# adjust path if triage.db is elsewhere
DB_PATH = "triage.db"

conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

# 👇 you must adapt this query to your real table names
# examples (only ONE of these will be correct in your project):
# cur.execute("SELECT * FROM appointments")
# cur.execute("SELECT * FROM slots WHERE booked = 1")
# cur.execute("SELECT * FROM appointment_slots WHERE status = 'confirmed'")
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
print("Tables:", [r["name"] for r in cur.fetchall()])

# once you know the table name, change this:
# cur.execute("SELECT * FROM <your_table>")
# rows = cur.fetchall()
# for r in rows:
#     print(dict(r))

conn.close()
