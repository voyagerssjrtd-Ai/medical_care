# Backend/db/init_triage_schema.py
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[1] / "data" / "inventory.db"

def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # 1) Clinicians table (simple for now)
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS clinicians (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            specialty TEXT
        );
        """
    )

    # 2) Triage session metadata
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS triage_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            created_by TEXT NOT NULL, -- 'patient' | 'clinician'
            triage_level TEXT,
            ai_summary TEXT,
            status TEXT DEFAULT 'draft',
            FOREIGN KEY(patient_id) REFERENCES patients(id)
        );
        """
    )

    # 3) Messages inside a triage session
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS triage_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            sender_type TEXT NOT NULL, -- 'patient' | 'clinician' | 'ai'
            message_text TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(session_id) REFERENCES triage_sessions(id)
        );
        """
    )

    # 4) Follow-up plans
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS followup_plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            plan_text TEXT NOT NULL,
            next_review_date TEXT,
            status TEXT DEFAULT 'planned',
            FOREIGN KEY(session_id) REFERENCES triage_sessions(id)
        );
        """
    )

    # 5) Seed one demo clinician (idempotent)
    cur.execute(
        """
        INSERT INTO clinicians (name, email, password, specialty)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(email) DO UPDATE SET
            name=excluded.name,
            password=excluded.password,
            specialty=excluded.specialty;
        """,
        ("Dr. Clinician", "clinician@careflow.ai", "password123", "General Medicine"),
    )

    conn.commit()
    conn.close()
    print("✅ Triage schema initialized and demo clinician seeded.")

if __name__ == "__main__":
    main()
