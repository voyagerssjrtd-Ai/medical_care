# Backend/db/seed_patients.py
import sqlite3
import json
from pathlib import Path

# Correct SQLite DB path
DB_PATH = Path(__file__).resolve().parents[1] / "data" / "inventory.db"
EHR_JSON_PATH = Path(__file__).resolve().parents[2] / "database" / "json_files" / "mock_ehr.json"

def map_ehr_to_db(patient):
    # Map EHR patient dict to DB schema
    # Use first two medications if available, else blank
    meds = patient.get("medications", [])
    med1 = meds[0] if len(meds) > 0 else {"name": "", "dose": "", "frequency": ""}
    med2 = meds[1] if len(meds) > 1 else {"name": "", "dose": "", "frequency": ""}
    vitals = patient.get("vitals", {})
    return {
        "email": f"{patient['name'].replace(' ', '').lower()}@ehr.local",  # synthetic email
        "name": patient.get("name", ""),
        "age": patient.get("age", None),
        "gender": patient.get("sex", "")[0].upper() if patient.get("sex") else None,
        "mrn": patient.get("id", ""),
        "primary_doctor": "",  # Not in EHR
        "last_visit": patient.get("last_visit_date", ""),
        "hr": vitals.get("heart_rate", None),
        "bp": vitals.get("blood_pressure", ""),
        "temp": vitals.get("temperature", None),
        "spo2": None,  # Not in EHR
        "appointment_title": "",  # Not in EHR
        "appointment_date": "",  # Not in EHR
        "appointment_location": "",  # Not in EHR
        "medication1": med1.get("name", ""),
        "medication1_dose": med1.get("dose", ""),
        "medication1_freq": med1.get("frequency", ""),
        "medication2": med2.get("name", ""),
        "medication2_dose": med2.get("dose", ""),
        "medication2_freq": med2.get("frequency", ""),
        "active_conditions": "; ".join(patient.get("conditions", [])),
        "plan": "",  # Not in EHR
        "next_steps": "",  # Not in EHR
    }

def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Ensure table exists
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            name TEXT,
            age INTEGER,
            gender TEXT,
            mrn TEXT,
            primary_doctor TEXT,
            last_visit TEXT,
            hr INTEGER,
            bp TEXT,
            temp REAL,
            spo2 INTEGER,
            appointment_title TEXT,
            appointment_date TEXT,
            appointment_location TEXT,
            medication1 TEXT,
            medication1_dose TEXT,
            medication1_freq TEXT,
            medication2 TEXT,
            medication2_dose TEXT,
            medication2_freq TEXT,
            active_conditions TEXT,
            plan TEXT,
            next_steps TEXT
        );
        """
    )

    patients = [
        {
            "email": "jasmine@careflow.ai",
            "name": "Jasmine",
            "age": 28,
            "gender": "F",
            "mrn": "MRN-000129",
            "primary_doctor": "Dr. Meera Raman",
            "last_visit": "2025-11-20",
            "hr": 80,
            "bp": "118/74",
            "temp": 36.4,
            "spo2": 99,
            "appointment_title": "OBGYN Consultation",
            "appointment_date": "2025-12-12 10:30 AM",
            "appointment_location": "Fertility Clinic - Room 3",
            "medication1": "Progesterone",
            "medication1_dose": "200 mg",
            "medication1_freq": "Once daily",
            "medication2": "Folic Acid",
            "medication2_dose": "0.5 mg",
            "medication2_freq": "Once daily",
            "active_conditions": "PCOS; Hypothyroid",
            "plan": "Monitor hormones; IUI cycle planned",
            "next_steps": "USG on 30 Nov; clinic review after scan",
        },
        {
            "email": "swetha@careflow.ai",
            "name": "Swetha Renganathan",
            "age": 33,
            "gender": "F",
            "mrn": "MRN-000210",
            "primary_doctor": "Dr. Elizabeth Cristy",
            "last_visit": "2025-11-20",
            "hr": 76,
            "bp": "120/80",
            "temp": 36.6,
            "spo2": 99,
            "appointment_title": "Follow-up Consultation",
            "appointment_date": "2025-12-18 11:00 AM",
            "appointment_location": "OPD – Room 5",
            "medication1": "Metformin",
            "medication1_dose": "500 mg",
            "medication1_freq": "Twice daily",
            "medication2": "Vitamin D",
            "medication2_dose": "1000 IU",
            "medication2_freq": "Once daily",
            "active_conditions": "Type 2 Diabetes; Vitamin D deficiency",
            "plan": "Continue current medications; monitor sugar; diet changes",
            "next_steps": "Lab tests before next visit; follow-up in 6 weeks",
        },
    ]

    for p in patients:
        cur.execute(
            """
            INSERT INTO patients (
                email, name, age, gender, mrn, primary_doctor, last_visit,
                hr, bp, temp, spo2,
                appointment_title, appointment_date, appointment_location,
                medication1, medication1_dose, medication1_freq,
                medication2, medication2_dose, medication2_freq,
                active_conditions, plan, next_steps
            )
            VALUES (
                :email, :name, :age, :gender, :mrn, :primary_doctor, :last_visit,
                :hr, :bp, :temp, :spo2,
                :appointment_title, :appointment_date, :appointment_location,
                :medication1, :medication1_dose, :medication1_freq,
                :medication2, :medication2_dose, :medication2_freq,
                :active_conditions, :plan, :next_steps
            )
            ON CONFLICT(email) DO UPDATE SET
                name=excluded.name,
                age=excluded.age,
                gender=excluded.gender,
                mrn=excluded.mrn,
                primary_doctor=excluded.primary_doctor,
                last_visit=excluded.last_visit,
                hr=excluded.hr,
                bp=excluded.bp,
                temp=excluded.temp,
                spo2=excluded.spo2,
                appointment_title=excluded.appointment_title,
                appointment_date=excluded.appointment_date,
                appointment_location=excluded.appointment_location,
                medication1=excluded.medication1,
                medication1_dose=excluded.medication1_dose,
                medication1_freq=excluded.medication1_freq,
                medication2=excluded.medication2,
                medication2_dose=excluded.medication2_dose,
                medication2_freq=excluded.medication2_freq,
                active_conditions=excluded.active_conditions,
                plan=excluded.plan,
                next_steps=excluded.next_steps;
            """,
            p,
        )

    # Load EHR patients from JSON
    if EHR_JSON_PATH.exists():
        with open(EHR_JSON_PATH, "r", encoding="utf-8") as f:
            ehr_data = json.load(f)
            ehr_patients = ehr_data.get("patients", [])
            for patient in ehr_patients:
                p = map_ehr_to_db(patient)
                cur.execute(
                    """
                    INSERT INTO patients (
                        email, name, age, gender, mrn, primary_doctor, last_visit,
                        hr, bp, temp, spo2,
                        appointment_title, appointment_date, appointment_location,
                        medication1, medication1_dose, medication1_freq,
                        medication2, medication2_dose, medication2_freq,
                        active_conditions, plan, next_steps
                    )
                    VALUES (
                        :email, :name, :age, :gender, :mrn, :primary_doctor, :last_visit,
                        :hr, :bp, :temp, :spo2,
                        :appointment_title, :appointment_date, :appointment_location,
                        :medication1, :medication1_dose, :medication1_freq,
                        :medication2, :medication2_dose, :medication2_freq,
                        :active_conditions, :plan, :next_steps
                    )
                    ON CONFLICT(email) DO UPDATE SET
                        name=excluded.name,
                        age=excluded.age,
                        gender=excluded.gender,
                        mrn=excluded.mrn,
                        primary_doctor=excluded.primary_doctor,
                        last_visit=excluded.last_visit,
                        hr=excluded.hr,
                        bp=excluded.bp,
                        temp=excluded.temp,
                        spo2=excluded.spo2,
                        appointment_title=excluded.appointment_title,
                        appointment_date=excluded.appointment_date,
                        appointment_location=excluded.appointment_location,
                        medication1=excluded.medication1,
                        medication1_dose=excluded.medication1_dose,
                        medication1_freq=excluded.medication1_freq,
                        medication2=excluded.medication2,
                        medication2_dose=excluded.medication2_dose,
                        medication2_freq=excluded.medication2_freq,
                        active_conditions=excluded.active_conditions,
                        plan=excluded.plan,
                        next_steps=excluded.next_steps;
                    """,
                    p,
                )
        print(f"✅ Seeded {len(ehr_patients)} EHR patient records into patients table")

    conn.commit()
    conn.close()
    print("✅ Seeded 2 patient records into patients table")

if __name__ == "__main__":
    main()
