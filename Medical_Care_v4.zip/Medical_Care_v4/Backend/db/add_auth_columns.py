import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[1] / "data" / "inventory.db"

def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # 1) Add password column to patients, if not present
    try:
        cur.execute("ALTER TABLE patients ADD COLUMN password TEXT")
        print("✅ Added 'password' column to patients table")
    except sqlite3.OperationalError as e:
        # If column already exists, ignore
        print(f"ℹ️ Skipping add password to patients: {e}")

    # 2) Add/ensure clinicians table exists with password column
    try:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS clinicians (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                email TEXT UNIQUE,
                password TEXT
            );
            """
        )
        print("✅ Ensured clinicians table exists")
    except sqlite3.OperationalError as e:
        print(f"ℹ️ Clinicians table create skipped: {e}")

    # 3) Seed / update demo clinician
    cur.execute(
        """
        INSERT INTO clinicians (name, email, password)
        VALUES (?, ?, ?)
        ON CONFLICT(email) DO UPDATE SET
            name=excluded.name,
            password=excluded.password;
        """,
        ("Dr. Clinician", "clinician@careflow.ai", "Clinician@123"),
    )
    print("✅ Seeded demo clinician clinician@careflow.ai")

    # 4) Set passwords for your two manual demo patients
    cur.execute(
        "UPDATE patients SET password = ? WHERE email = ?",
        ("Jasmine@123", "jasmine@careflow.ai"),
    )
    cur.execute(
        "UPDATE patients SET password = ? WHERE email = ?",
        ("Swetha@123", "swetha@careflow.ai"),
    )
    print("✅ Set passwords for jasmine@careflow.ai and swetha@careflow.ai")

    # 5) Optional: set a default password for all other EHR patients
    cur.execute(
        """
        UPDATE patients
        SET password = COALESCE(password, 'Patient@123')
        WHERE password IS NULL
        """
    )
    print("✅ Set default password 'Patient@123' for other patients")

    conn.commit()
    conn.close()
    print("🎉 Auth columns + demo data ready.")

if __name__ == "__main__":
    main()
