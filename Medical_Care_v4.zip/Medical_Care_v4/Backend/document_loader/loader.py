
from langchain_community.document_loaders import PyPDFLoader
from langchain_core.documents import Document
from pathlib import Path
import os
import json


BASE_DIR = Path(__file__).resolve().parents[1]  # points to Backend/
LEGACY_DATA_DIR = BASE_DIR / "data"
ROOT_DB_DIR = BASE_DIR.parent / "database"


def load_txts():
    """Load all .txt files from the legacy Backend/data/txt_files directory.

    Uses paths relative to the repository instead of hard-coded absolute paths.
    """

    txt_folder = LEGACY_DATA_DIR / "txt_files"
    if not txt_folder.exists():
        return []

    txt_files = [p for p in txt_folder.iterdir() if p.suffix.lower() == ".txt"]

    all_docs = []
    for txt_file in txt_files:
        with txt_file.open("r", encoding="utf-8") as f:
            content = f.read()
            doc = Document(
                page_content=content,
                metadata={"source": txt_file.name},
            )
            all_docs.append(doc)
    return all_docs


def load_jsons():
    """Load the EHR JSON file from the root-level database/json_files folder.

    This replaces the previous hard-coded absolute Windows path and instead
    resolves the file relative to the Backend/ folder.
    """

    # Prefer the new root-level database/json_files, fall back to legacy location
    candidates = [
        ROOT_DB_DIR / "json_files" / "mock_ehr.json",
        LEGACY_DATA_DIR / "json_files" / "mock_ehr.json",
    ]

    for path in candidates:
        if path.exists():
            with path.open("r", encoding="utf-8") as f:
                return json.load(f)

    raise FileNotFoundError("mock_ehr.json not found in expected database/data locations")

def get_patient_by_id(patient_id):
    ehr_data = load_jsons()
    for patient in ehr_data.get("patients", []):
        if patient.get("id") == patient_id:
            return patient
    return None 

def json_to_text(d, prefix="- "):
    lines = []
    for key, value in d.items():
        key_name = key.replace("_", " ").title()
        if isinstance(value, dict):
            lines.append(f"{prefix}{key_name}:")
            lines.extend([f"  {line}" for line in json_to_text(value, prefix=prefix)])
        elif isinstance(value, list):
            if all(isinstance(i, dict) for i in value):
                lines.append(f"{prefix}{key_name}:")
                for item in value:
                    lines.extend([f"  {line}" for line in json_to_text(item, prefix=prefix)])
            else:
                lines.append(f"{prefix}{key_name}: {', '.join(map(str,value))}")
        else:
            lines.append(f"{prefix}{key_name}: {value}")
    return lines
