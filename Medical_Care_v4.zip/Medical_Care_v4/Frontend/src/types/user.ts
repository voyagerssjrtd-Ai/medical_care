export interface UserProfile {
  name: string;
  email: string;
  role: "patient" | "clinician";
  token: string;
  patient_id?: number | null;
  clinician_id?: number | null;
  picture?: string | null;
}
