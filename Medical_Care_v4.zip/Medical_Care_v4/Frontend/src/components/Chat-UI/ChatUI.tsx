// src/components/Chat-UI/ChatUI.tsx
import React, { useState, useEffect, useRef } from "react";
import { ChatBackend, Message } from "../../types/chat";
import { MessageBubble } from "./MessageBubble";
import { ArrowUpCircle, Mic, UploadCloud } from "lucide-react";
import {
  handleUserInput,
  sendWorkflowMessage,
} from "../../adapters/chatservice";
import { useAuth } from "../../contexts/AuthContext";
import { useNavigate, useLocation } from "react-router-dom";

// -------- Patient types --------
interface PatientSummary {
  email: string;
  name: string;
  age: number;
  gender: string;
  mrn: string;
  primary_doctor: string;
  last_visit: string;

  hr: number;
  bp: string;
  temp: number;
  spo2: number;

  appointment_title: string | null;
  appointment_date: string | null;
  appointment_location: string | null;

  medication1: string | null;
  medication1_dose: string | null;
  medication1_freq: string | null;

  medication2: string | null;
  medication2_dose: string | null;
  medication2_freq: string | null;

  active_conditions: string | null;
  plan: string | null;
  next_steps: string | null;
}

// -------- Triage alert types --------
type TriageSeverity = "critical" | "medium" | "low";

interface TriageAlert {
  severity: TriageSeverity;
  triageLevel: string;
  message: string;
}

// -------- Helpers --------
function generateTitleFromMessage(text: string): string {
  if (!text) return "New Chat";
  let cleaned = text
    .replace(/[^a-zA-Z0-9 ]/g, "")
    .split(" ")
    .filter((w) => w.length > 2)
    .slice(0, 6)
    .join(" ");
  return cleaned
    ? cleaned.charAt(0).toUpperCase() + cleaned.slice(1) + "…"
    : "New Chat";
}

// -------- Workflow formatter (REFINED) --------
function formatWorkflow(wf: any, patientName?: string) {
  if (!wf) return "No workflow result.";

  const triage = wf.triage ?? {};
  const plan = triage.follow_up_plan ?? {};
  const appointment = wf.appointment ?? {};
  const guard = wf.guardrails ?? {};

  const level =
    plan.triage_level ??
    triage.triage_level ??
    triage.risk_level ??
    "Not specified";

  const reasoning =
    plan.reasoning ??
    triage.reasoning ??
    "No reasoning provided by the model.";

  // Build a nice follow-up section from structured fields
  const lines: string[] = [];

  if (plan.urgent_evaluation) {
    lines.push(
      `- **Urgent evaluation:** ${String(plan.urgent_evaluation)}`
    );
  }

  if (Array.isArray(plan.patient_actions) && plan.patient_actions.length) {
    lines.push(`- **Patient actions:**`);
    for (const a of plan.patient_actions) {
      lines.push(`  • ${String(a)}`);
    }
  }

  if (Array.isArray(plan.clinician_tasks) && plan.clinician_tasks.length) {
    lines.push(`- **Clinician tasks:**`);
    for (const t of plan.clinician_tasks) {
      lines.push(`  • ${String(t)}`);
    }
  }

  // Fallback if we didn't get structured actions
  if (lines.length === 0 && Array.isArray(plan.recommendations)) {
    lines.push(`- **Follow-up recommendations:**`);
    for (const r of plan.recommendations) {
      lines.push(`  • ${String(r)}`);
    }
  }

  let text = `**Triage summary for ${
    patientName || "this patient"
  }**\n\n- **Level:** ${level}\n`;

  if (lines.length > 0) {
    text += `\n**Follow-up plan**\n${lines.join("\n")}\n`;
  }

  text += `\n**Clinical reasoning**\n${reasoning}\n`;

  if (appointment.status || appointment.details || appointment.message) {
    text += `\n**Appointment**\n`;
    if (appointment.status) text += `- Status: ${appointment.status}\n`;
    if (appointment.details) text += `- Details: ${appointment.details}\n`;
    if (appointment.message && !appointment.details) {
      text += `- Details: ${appointment.message}\n`;
    }
  }

  if (guard.message) {
    text += `\n**Guardrails / Safety checks**\n${guard.message}\n`;
  }

  return text;
}

export default function ChatUI({ backend }: { backend: ChatBackend }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // 🔒 Redirect to login if not authenticated
  useEffect(() => {
    if (!user) navigate("/");
  }, [user, navigate]);

  // ----- Route → /chat?patient=...&autotriage=true -----
  const [routePatientEmail, setRoutePatientEmail] = useState<string | null>(
    null
  );
  const [routeAutoTriage, setRouteAutoTriage] = useState<boolean>(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    setRoutePatientEmail(params.get("patient"));
    setRouteAutoTriage(params.get("autotriage") === "true");
  }, [location.search]);

  // ----- Triage alert (color-coded banner) -----
  const [triageAlert, setTriageAlert] = useState<TriageAlert | null>(null);

  // ----- Core chat state -----
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [streamingByChat, setStreamingByChat] = useState<
    Record<string, string>
  >({});
  const [isStreaming, setIsStreaming] = useState(false);
  const [chats, setChats] = useState<
    { id: string; title: string; messages: Message[] }[]
  >([]);
  const [currentChat, setCurrentChat] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const [recognition, setRecognition] = useState<any>(null);
  const [recording, setRecording] = useState(false);
  const [speechLang] = useState("en-US");
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const controllerRef = useRef<AbortController | null>(null);
  const collectedRef = useRef<Record<string, string>>({});
  const currentChatRef = useRef<string | null>(currentChat);
  useEffect(() => {
    currentChatRef.current = currentChat;
  }, [currentChat]);
  const [error, setError] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [bookingAppointment, setBookingAppointment] = useState(false);

  // ----- Patient record state -----
  const [patient, setPatient] = useState<PatientSummary | null>(null);
  const [allPatients, setAllPatients] = useState<PatientSummary[]>([]);
  const [patientLoading, setPatientLoading] = useState(false);
  const [patientError, setPatientError] = useState<string | null>(null);

  // Clinician-selected patient (for triage)
  const [selectedPatient, setSelectedPatient] = useState<PatientSummary | null>(
    null
  );

  const handlePatientSelect = (p: PatientSummary) => {
    setSelectedPatient(p);
    setInput(
      `Please provide a triage summary for ${p.name} (${p.mrn}) and suggest follow-up steps.`
    );
  };

  // ----- Hero / avatar image -----
  const [heroImage, setHeroImage] = useState<string | null>(() => {
    try {
      return localStorage.getItem("chatui.heroImage");
    } catch {
      return null;
    }
  });
  const heroInputRef = useRef<HTMLInputElement | null>(null);
  const attachInputRef = useRef<HTMLInputElement | null>(null);

  function setHeroFromFile(file?: File) {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setHeroImage(url);
    try {
      localStorage.setItem("chatui.heroImage", url);
    } catch {
      // ignore
    }
  }

  // ----- Fetch patient data from backend -----
  useEffect(() => {
    if (!user) {
      setPatient(null);
      setAllPatients([]);
      return;
    }
    if (!user.email) return;

    const fetchAllPatients = async () => {
      setPatientLoading(true);
      setPatientError(null);
      try {
        const res = await fetch(
          "http://localhost:8000/patients?user_type=clinician"
        );
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        setAllPatients(data);
      } catch (err) {
        console.error("Failed to load all patients", err);
        setPatientError("Unable to load all patient records.");
        setAllPatients([]);
      } finally {
        setPatientLoading(false);
      }
    };

    const fetchPatient = async () => {
      setPatientLoading(true);
      setPatientError(null);
      try {
        const res = await fetch(
          `http://localhost:8000/patients?user_type=patient&email=${encodeURIComponent(
            user.email ?? ""
          )}`
        );
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        setPatient(data);
      } catch (err) {
        console.error("Failed to load patient record", err);
        setPatientError("Unable to load patient record.");
        setPatient(null);
      } finally {
        setPatientLoading(false);
      }
    };

    if (user.role === "clinician") {
      fetchAllPatients();
    } else {
      fetchPatient();
    }
  }, [user]);

  // ----- Auto-select / auto-triage from route -----
  useEffect(() => {
    if (user?.role !== "clinician") return;
    if (!routePatientEmail) return;
    if (!allPatients || allPatients.length === 0) return;

    const match = allPatients.find(
      (p) => p.email.toLowerCase() === routePatientEmail.toLowerCase()
    );
    if (!match) return;

    setSelectedPatient(match);
    setInput(
      `Please provide a triage summary for ${match.name} (${match.mrn}) and suggest follow-up steps.`
    );

    if (routeAutoTriage) {
      // slight delay so state (input + selectedPatient) is ready
      setTimeout(() => {
        sendMessage();
      }, 150);
    }
  }, [user, routePatientEmail, routeAutoTriage, allPatients]);

  // ----- Speech recognition -----
  useEffect(() => {
    const SpeechRec =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (SpeechRec) {
      const rec = new SpeechRec();
      rec.continuous = true;
      rec.interimResults = false;
      rec.lang = speechLang;
      rec.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((r: any) => r[0].transcript)
          .join("");
        setInput((prev) => prev + transcript + " ");
      };
      rec.onend = () => setRecording(false);
      rec.onerror = () => setRecording(false);
      setRecognition(rec);
    }
  }, [speechLang]);

  const toggleRecording = () => {
    if (!recognition) {
      alert("Speech recognition not supported in this browser");
      return;
    }
    if (recording) {
      recognition.stop();
      setRecording(false);
    } else {
      recognition.start();
      setRecording(true);
    }
  };

  // ----- Load / persist chats from localStorage -----
  useEffect(() => {
    const saved = localStorage.getItem("chats");
    if (saved) {
      try {
        setChats(JSON.parse(saved));
      } catch {
        // ignore bad data
      }
    }
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem("chats", JSON.stringify(chats));
    } catch {
      // ignore
    }
  }, [chats]);

  // ----- Title & suggestions helpers -----
  const requestTitleFromAssistant = async (
    replyText: string,
    chatId: string
  ) => {
    if (!replyText) return;
    try {
      const prompt = `Generate a concise 3-6 word conversation title (no punctuation) summarizing this assistant reply in a medical/patient context:\n\n"${replyText}"\n\nTitle:`;
      const res = await handleUserInput(backend, prompt, []);
      const titleText = (res?.content ?? String(res))
        .toString()
        .trim()
        .split("\n")[0];
      const finalTitle =
        titleText && titleText.length > 0
          ? titleText
          : generateTitleFromMessage(replyText);
      setChats((prev) =>
        prev.map((c) => (c.id === chatId ? { ...c, title: finalTitle } : c))
      );
    } catch (e) {
      console.warn("Title generation failed, using fallback", e);
      setChats((prev) =>
        prev.map((c) =>
          c.id === chatId
            ? { ...c, title: generateTitleFromMessage(replyText) }
            : c
        )
      );
    }
  };

  const requestSuggestionsFromAssistant = async (replyText: string) => {
    try {
      const prompt = `From the assistant reply below, produce exactly 3 short follow-up questions a PATIENT might ask (2-8 words each), each on a separate line. Do NOT add numbering.\n\nAssistant reply:\n${replyText}\n\nSuggestions:\n`;
      const res = await handleUserInput(backend, prompt, []);
      const raw = (res?.content ?? String(res)).toString().trim();
      const lines = raw
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean)
        .slice(0, 3);
      if (lines.length === 0) {
        setSuggestions([
          "Can you explain that in simple terms?",
          "What symptoms should I watch for?",
          "When should I seek urgent care?",
        ]);
      } else {
        setSuggestions(lines);
      }
    } catch {
      setSuggestions([]);
    }
  };

  // ----- Scroll helpers -----
  const isUserAtBottom = (): boolean => {
    const container = messagesEndRef.current?.parentElement;
    if (!container) return true;
    const distance =
      container.scrollHeight - container.scrollTop - container.clientHeight;
    return distance < 150;
  };

  const maybeAutoScroll = (force = false) => {
    if (!messagesEndRef.current) return;
    if (force || isUserAtBottom()) {
      messagesEndRef.current.scrollIntoView({ behavior: "auto" });
    }
  };

  const stopStreaming = () => {
    if (controllerRef.current) controllerRef.current.abort();
    setIsStreaming(false);
    setSending(false);
    if (currentChatRef.current) {
      setStreamingByChat((prev) => ({
        ...prev,
        [currentChatRef.current!]: prev[currentChatRef.current!] ?? "",
      }));
    }
  };

  // ----- Send message (unified workflow) -----
  const sendMessage = async () => {
    if ((!input.trim() && attachedFiles.length === 0) || sending) return;
    if (recognition && recording) {
      recognition.stop();
      setRecording(false);
    }

    let activeChatId = currentChat;
    if (!activeChatId) {
      activeChatId = Date.now().toString();
      const newChat = {
        id: activeChatId,
        title: generateTitleFromMessage(input),
        messages: [] as Message[],
      };
      setChats((prev) => [...prev, newChat]);
      setCurrentChat(activeChatId);
      setMessages([]);
    }

    let userContent = input;
    if (attachedFiles.length > 0) {
      userContent +=
        "\n[Attached: " + attachedFiles.map((f) => f.name).join(", ") + "]";
    }

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: userContent,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setChats((prev) =>
      prev.map((c) =>
        c.id === activeChatId
          ? {
              ...c,
              messages: [...c.messages, userMsg],
              title:
                c.messages.length === 0
                  ? generateTitleFromMessage(userContent)
                  : c.title,
            }
          : c
      )
    );

    setSending(true);
    setError(null);
    setSuggestions([]);

    if (activeChatId) {
      collectedRef.current[activeChatId] = "";
      setStreamingByChat((prev) => ({ ...prev, [activeChatId!]: "" }));
    }

    try {
      // Determine patient_id for workflow
      let patient_id = "";
      if (user?.role === "clinician" && selectedPatient) {
        patient_id = selectedPatient.mrn;
      } else if (user?.role === "patient" && patient) {
        patient_id = patient.mrn;
      } else if (user?.email) {
        patient_id = user.email;
      }

      const workflowResp = await sendWorkflowMessage(patient_id, userContent);

      // 1) Chat content from workflow
      const botContent = formatWorkflow(
        workflowResp,
        selectedPatient?.name || patient?.name || user?.name
      );

      // 2) Derive severity from triage level for top banner
      const triageLevelRaw =
        workflowResp?.triage?.follow_up_plan?.triage_level ??
        workflowResp?.triage?.triage_level ??
        "";

      let severity: TriageSeverity = "low";
      const lvl = triageLevelRaw.toLowerCase();
      if (lvl.includes("emergency") || lvl.includes("high")) {
        severity = "critical";
      } else if (lvl.includes("medium")) {
        severity = "medium";
      } else {
        severity = "low";
      }

      // 3) Get appointment message if present
      const appointmentMessage =
        workflowResp?.appointment?.message ??
        workflowResp?.appointment?.details ??
        "";

      // 4) Update alert banner state
      setTriageAlert({
        severity,
        triageLevel: triageLevelRaw || "Not specified",
        message:
          appointmentMessage ||
          "Consider booking a consultation to review this triage result.",
      });

      // 5) Push assistant message
      const botMsg: Message = {
        id: Date.now().toString() + "-bot",
        role: "assistant",
        content: botContent,
        createdAt: new Date().toISOString(),
      };

      setChats((prev) =>
        prev.map((c) =>
          c.id === activeChatId
            ? { ...c, messages: [...c.messages, botMsg] }
            : c
        )
      );
      if (currentChatRef.current === activeChatId) {
        setMessages((prev) => [...prev, botMsg]);
      }
      setInput("");
      setAttachedFiles([]);
      try {
        await requestTitleFromAssistant(botMsg.content, activeChatId!);
        await requestSuggestionsFromAssistant(botMsg.content);
      } catch {
        // ignore
      }
      maybeAutoScroll(true);
    } catch (err: any) {
      console.error("sendMessage error", err);
      setError(
        err?.message || "An error occurred while sending your message."
      );
    } finally {
      setSending(false);
      setIsStreaming(false);
      inputRef.current?.focus();
    }
  };

  // ----- Auto-resize textarea -----
  useEffect(() => {
    const el = inputRef.current;
    if (!el) return;
    el.style.height = "auto";
    const scrollHeight = el.scrollHeight;
    const MAX_HEIGHT = 160;
    if (scrollHeight > MAX_HEIGHT) {
      el.style.height = `${MAX_HEIGHT}px`;
      el.style.overflowY = "auto";
    } else {
      el.style.height = `${scrollHeight}px`;
      el.style.overflowY = "hidden";
    }
  }, [input]);

  // ----- History popup -----
  const [showHistory, setShowHistory] = useState(false);
  const historyBtnRef = useRef<HTMLButtonElement | null>(null);
  const [historyStyle, setHistoryStyle] =
    useState<React.CSSProperties | null>(null);
  const historyContainerRef = useRef<HTMLDivElement | null>(null);

  const openHistoryAnchored = () => {
    const btn = historyBtnRef.current;
    if (!btn) {
      setShowHistory(true);
      setHistoryStyle(null);
      return;
    }
    const rect = btn.getBoundingClientRect();
    const width = 320;
    const top = rect.bottom + window.scrollY + 8;
    let left = rect.left + window.scrollX;
    if (left + width > window.innerWidth - 8)
      left = window.innerWidth - width - 8;
    if (left < 8) left = 8;
    setHistoryStyle({
      position: "absolute",
      top: `${top}px`,
      left: `${left}px`,
      width: `${width}px`,
      zIndex: 1200,
    });
    setShowHistory(true);
  };

  useEffect(() => {
    if (!showHistory) return;
    function reposition() {
      const btn = historyBtnRef.current;
      if (!btn) return;
      const rect = btn.getBoundingClientRect();
      const width = 320;
      const top = rect.bottom + window.scrollY + 8;
      let left = rect.left + window.scrollX;
      if (left + width > window.innerWidth - 8)
        left = window.innerWidth - width - 8;
      if (left < 8) left = 8;
      setHistoryStyle((s) => ({
        ...(s || {}),
        top: `${top}px`,
        left: `${left}px`,
      }));
    }
    window.addEventListener("resize", reposition);
    window.addEventListener("scroll", reposition, true);
    return () => {
      window.removeEventListener("resize", reposition);
      window.removeEventListener("scroll", reposition, true);
    };
  }, [showHistory]);

  useEffect(() => {
    if (!showHistory) return;
    function onDocClick(e: MouseEvent) {
      const target = e.target as Node;
      if (!historyContainerRef.current) return;
      if (historyContainerRef.current.contains(target)) return;
      if (historyBtnRef.current && historyBtnRef.current.contains(target))
        return;
      setShowHistory(false);
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, [showHistory]);

  function selectHistory(id: string) {
    setCurrentChat(id);
    const found = chats.find((c) => c.id === id);
    setMessages(found ? found.messages : []);
    setShowHistory(false);
  }

  function deleteHistory(id: string) {
    setChats((prev) => prev.filter((c) => c.id !== id));
    if (currentChat === id) {
      setCurrentChat(null);
      setMessages([]);
    }
  }

  // ----- Profile popup -----
  const [showProfile, setShowProfile] = useState(false);
  const nameRef = useRef<HTMLDivElement | null>(null);
  const profileContainerRef = useRef<HTMLDivElement | null>(null);
  const [profileStyle, setProfileStyle] =
    useState<React.CSSProperties | null>(null);

  const openProfileAnchored = () => {
    const node = nameRef.current;
    if (!node) {
      setShowProfile(true);
      return;
    }
    const rect = node.getBoundingClientRect();
    const width = 300;
    const top = rect.bottom + window.scrollY + 8;
    let left = rect.left + window.scrollX;
    if (left + width > window.innerWidth - 8)
      left = window.innerWidth - width - 8;
    if (left < 8) left = 8;
    setProfileStyle({
      position: "absolute",
      top: `${top}px`,
      left: `${left}px`,
      width: `${width}px`,
      zIndex: 1200,
    });
    setShowProfile(true);
  };

  useEffect(() => {
    if (!showProfile) return;
    function reposition() {
      const node = nameRef.current;
      if (!node) return;
      const rect = node.getBoundingClientRect();
      const width = 300;
      const top = rect.bottom + window.scrollY + 8;
      let left = rect.left + window.scrollX;
      if (left + width > window.innerWidth - 8)
        left = window.innerWidth - width - 8;
      if (left < 8) left = 8;
      setProfileStyle((s) => ({
        ...(s || {}),
        top: `${top}px`,
        left: `${left}px`,
      }));
    }
    window.addEventListener("resize", reposition);
    window.addEventListener("scroll", reposition, true);
    return () => {
      window.removeEventListener("resize", reposition);
      window.removeEventListener("scroll", reposition, true);
    };
  }, [showProfile]);

  useEffect(() => {
    if (!showProfile) return;
    function onDocClick(e: MouseEvent) {
      const target = e.target as Node;
      if (!profileContainerRef.current) return;
      if (profileContainerRef.current.contains(target)) return;
      if (nameRef.current && nameRef.current.contains(target)) return;
      setShowProfile(false);
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, [showProfile]);

  // small blob svg
  const BlobWithImage = ({
    src,
    size = 96,
  }: {
    src?: string | null;
    size?: number;
  }) => {
    const path =
      "M86.9,-72.3C108.3,-52,119.1,-26,118.1,-1.8C117.1,22.4,104.3,44.9,84.7,62.1C65.1,79.3,38.6,91.1,10.2,92.9C-18.2,94.7,-48.5,86.5,-69.8,68.4C-91.1,50.4,-103.3,22.4,-103.8,-5.5C-104.3,-33.4,-93.2,-61.2,-72.9,-81.5C-52.6,-101.8,-26.3,-114.6,2.4,-116.2C31.1,-117.8,62.1,-108.6,86.9,-72.3Z";
    const view = 240;
    return (
      <svg
        viewBox={`-120 -120 ${view} ${view}`}
        style={{ width: size, height: size }}
      >
        <defs>
          <clipPath id="blobClipHero">
            <path d={path} transform="scale(0.6) translate(0,32)" />
          </clipPath>
          <linearGradient id="blobGradHero" x1="0" x2="1">
            <stop offset="0%" stopColor="#35C3FF" />
            <stop offset="100%" stopColor="#0FB5C9" />
          </linearGradient>
          <filter id="blobShadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow
              dx="0"
              dy="8"
              stdDeviation="20"
              floodColor="#7BC7EB"
              floodOpacity="0.4"
            />
          </filter>
        </defs>

        <g clipPath="url(#blobClipHero)" filter="url(#blobShadow)">
          <rect
            x="-120"
            y="-120"
            width={view}
            height={view}
            fill="url(#blobGradHero)"
          />
          {src ? (
            <image
              href={src}
              x="-120"
              y="-120"
              width={view}
              height={view}
              preserveAspectRatio="xMidYMid slice"
            />
          ) : null}
        </g>

        <path
          d={path}
          transform="scale(0.6) translate(0,32)"
          fill="none"
          stroke="rgba(255,255,255,0.4)"
          strokeWidth="1.2"
        />
      </svg>
    );
  };

  const sendPrompt = (p: string) => {
    setInput(p);
    setTimeout(() => sendMessage(), 80);
  };

  const StyleBlock = () => (
    <style>{`
      .glass-btn {
        background: #ffffff;
        border-radius: 999px;
        border: 1px solid #cfe5f5;
        color: #0369a1;
        padding: 6px 14px;
        font-size: 0.75rem;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        transition: all .15s ease;
        box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
      }
      .glass-btn:hover {
        background: #e0f3ff;
        border-color: #7ac4f4;
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.12);
      }

      @keyframes slideFade {
        from { transform: translateY(-8px); opacity: 0; }
        to   { transform: translateY(0); opacity: 1; }
      }
      .popup-animate {
        animation: slideFade 220ms cubic-bezier(.2,.9,.2,1);
      }

      @keyframes floaty {
        0%, 100% { transform: translateY(0px); }
        50% { transform: translateY(-6px); }
      }

      .nice-scrollbar::-webkit-scrollbar {
        width: 6px;
      }
      .nice-scrollbar::-webkit-scrollbar-thumb {
        background: rgba(148,163,184,0.7);
        border-radius: 999px;
      }
    `}</style>
  );

  // ---- UPDATED: severity + booking helpers used by chat body ----
  const getSeverityFromContent = (
    content: string
  ): TriageSeverity | null => {
    // Look specifically for the formatted level line:
    // "- **Level:** high/urgent"
    const match = content.match(/- \*\*Level:\*\*\s*([^\n]+)/i);
    const levelText = match ? match[1].trim().toLowerCase() : "";

    if (!levelText) return null;

    if (levelText.includes("emergency")) {
      return "critical";
    }
    if (levelText.includes("high")) {
      return "critical";
    }
    if (levelText.includes("medium")) {
      return "medium";
    }
    if (levelText.includes("low")) {
      return "low";
    }

    return null;
  };

  const bookAppointmentFromContent = async (content: string) => {
    const severity = getSeverityFromContent(content);
    if (!severity) {
      alert("No triage severity detected in this reply.");
      return;
    }

    // Map severity → triage_level to send to backend
    const match = content.match(/- \*\*Level:\*\*\s*([^\n]+)/i);
    const levelText = match ? match[1].trim().toLowerCase() : "";

    let triageLevel = "low/self-care";
    if (levelText.includes("emergency")) {
      triageLevel = "emergency";
    } else if (levelText.includes("high")) {
      triageLevel = "high/urgent";
    } else if (levelText.includes("medium")) {
      triageLevel = "medium";
    }

    // Compute patient_id the same way as in sendMessage
    let patient_id = "";
    if (user?.role === "clinician" && selectedPatient) {
      patient_id = selectedPatient.mrn;
    } else if (user?.role === "patient" && patient) {
      patient_id = patient.mrn;
    } else if (user?.email) {
      patient_id = user.email;
    }

    if (!patient_id) {
      alert("No patient selected / available to book appointment.");
      return;
    }

    setBookingAppointment(true);
    try {
      const body = {
        patient_id,
        // For now we just send the reply text as symptoms summary
        symptoms: content,
        triage_level: triageLevel,
        preferred_times: [] as string[],
      };

      const res = await fetch("http://localhost:8000/appointments/book", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const data = await res.json(); // { message: string }
      alert("Appointment booked: " + (data.message || "Success"));
    } catch (err: any) {
      console.error("Book appointment error", err);
      alert(
        "Failed to book appointment: " + (err?.message || "Unknown error")
      );
    } finally {
      setBookingAppointment(false);
    }
  };

  // ---------- RENDER ----------
  return (
    <div className="min-h-screen w-full bg-[#F5FBFF] text-slate-800">
      <StyleBlock />

      {/* Top aqua band similar to login page */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-20 bg-[#D6F7FC]" />

      <div className="relative mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 lg:h-screen lg:flex-row lg:py-6">
        {/* LEFT: Chat area */}
        <div className="flex-1 lg:flex-[3] flex flex-col">
          <div className="flex flex-1 flex-col rounded-3xl bg-[#DDF3FF] p-[1px] shadow-[0_18px_55px_rgba(15,23,42,0.12)] border border-[#CDE6F7]">
            <div className="flex h-full flex-col rounded-[1.35rem] bg-white">
              {/* Header */}
              <div className="flex items-start justify-between px-6 pt-4 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-4">
                  <div
                    className="transform-gpu"
                    style={{
                      animation: "floaty 5.4s ease-in-out infinite",
                    }}
                  >
                    <BlobWithImage src={heroImage} size={84} />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-semibold tracking-tight text-slate-900">
                        Symptom Assistant
                      </h2>
                      <span className="rounded-full bg-[#E6F7FF] px-2 py-0.5 text-[10px] font-medium text-[#0F9BD4] border border-[#C8E9FF]">
                        CareFlow e-Hospital
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 max-w-md leading-snug">
                      Capture your symptoms in your own words. The assistant
                      will help triage urgency and suggest safe follow-up steps.
                    </p>
                    <button
                      className="text-[11px] text-sky-600 underline underline-offset-4"
                      onClick={() => heroInputRef.current?.click()}
                    >
                      Change assistant illustration
                    </button>
                    <input
                      ref={heroInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) =>
                        e.target.files && setHeroFromFile(e.target.files[0])
                      }
                    />
                  </div>
                </div>

                {/* user / session area */}
                <div className="flex flex-col items-end gap-2">
                  <div className="flex items-center gap-3">
                    <img
                      src={user?.picture ?? ""}
                      alt="avatar"
                      className="w-9 h-9 rounded-full object-cover bg-sky-50 border border-sky-100"
                    />
                    <div className="text-right">
                      <div
                        ref={nameRef}
                        onClick={openProfileAnchored}
                        className="cursor-pointer text-xs font-medium text-slate-900 hover:text-sky-700 hover:underline"
                      >
                        {user?.name ?? user?.email ?? "Patient"}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {user?.role === "clinician"
                          ? "Clinical console"
                          : "Patient portal"}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-1">
                    <button
                      onClick={() => {
                        const id = Date.now().toString();
                        setChats([
                          ...chats,
                          { id, title: "New symptom session", messages: [] },
                        ]);
                        setCurrentChat(id);
                        setMessages([]);
                        setTriageAlert(null); // reset alert for new session
                      }}
                      className="glass-btn"
                    >
                      New session
                    </button>

                    <button
                      ref={historyBtnRef}
                      onClick={openHistoryAnchored}
                      className="glass-btn"
                    >
                      History
                    </button>
                  </div>
                </div>
              </div>

              {/* Chat body */}
              <div className="flex-1 flex flex-col px-4 pb-3 pt-2 gap-2">
                <div
                  className="flex-1 overflow-y-auto rounded-2xl bg-[#F7FBFF] border border-[#E0ECF7] px-4 py-4 nice-scrollbar"
                  style={{ minHeight: 0 }}
                >
                  <div className="space-y-4">
                    {messages.length === 0 && (
                      <div className="rounded-2xl bg-white border border-dashed border-[#D4E6F7] p-4 text-slate-700 text-sm">
                        <h3 className="text-base font-semibold mb-1 text-slate-900">
                          Welcome to the symptom assistant
                        </h3>
                        <p className="text-xs mb-3 text-slate-600">
                          Share what you&apos;re experiencing. You can mention
                          when it started, how it feels, and any medical history
                          you have.
                        </p>
                        <div className="grid gap-2 text-xs">
                          <button
                            onClick={() =>
                              sendPrompt(
                                "I have had a fever and cough for two days."
                              )
                            }
                            className="rounded-xl border border-[#D7E7F7] bg-white px-3 py-2 text-left hover:border-sky-400 hover:bg-[#F3FAFF]"
                          >
                            “I have had a fever and cough for two days.”
                          </button>
                          <button
                            onClick={() =>
                              sendPrompt(
                                "I feel chest pain when I walk up stairs."
                              )
                            }
                            className="rounded-xl border border-[#D7E7F7] bg-white px-3 py-2 text-left hover:border-sky-400 hover:bg-[#F3FAFF]"
                          >
                            “I feel chest pain when I walk up stairs.”
                          </button>
                          <button
                            onClick={() =>
                              sendPrompt(
                                "My child has a rash and mild fever."
                              )
                            }
                            className="rounded-xl border border-[#D7E7F7] bg-white px-3 py-2 text-left hover:border-sky-400 hover:bg-[#F3FAFF]"
                          >
                            “My child has a rash and mild fever.”
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Triage-aware messages block */}
                    <div className="space-y-3">
                      {messages.map((msg) => {
                        // user messages: just show normally
                        if (msg.role !== "assistant") {
                          return (
                            <MessageBubble key={msg.id} message={msg} />
                          );
                        }

                        // assistant replies: check severity based on Level line
                        const severity = getSeverityFromContent(msg.content);

                        if (!severity) {
                          // No triage Level, show bubble only
                          return (
                            <MessageBubble key={msg.id} message={msg} />
                          );
                        }

                        let bannerClasses =
                          "p-3 mb-2 rounded-xl text-sm flex items-center justify-between";
                        let colorClasses = "";
                        let badgeText = "";

                        if (severity === "critical") {
                          colorClasses =
                            "bg-red-50 border border-red-300 text-red-700";
                          badgeText = "High / emergency risk";
                        } else if (severity === "medium") {
                          colorClasses =
                            "bg-amber-50 border border-amber-300 text-amber-800";
                          badgeText = "Moderate concern";
                        } else {
                          colorClasses =
                            "bg-sky-50 border border-sky-300 text-sky-800";
                          badgeText = "Low risk / self-care";
                        }

                        return (
                          <div key={msg.id}>
                            <div className={`${bannerClasses} ${colorClasses}`}>
                              <div className="text-xs">
                                <div className="font-semibold mb-0.5">
                                  ⚕️ Triage result: {badgeText}
                                </div>
                                <div className="text-[11px]">
                                  This assessment is based on your symptoms and
                                  history. Please follow the suggested steps,
                                  and book an appointment if you&apos;re unsure.
                                </div>
                              </div>

                              <button
                                className={
                                  "ml-3 px-3 py-1.5 rounded-full text-[11px] font-medium shadow-sm " +
                                  (severity === "critical"
                                    ? "bg-red-600 text-white hover:bg-red-700"
                                    : severity === "medium"
                                    ? "bg-amber-500 text-white hover:bg-amber-600"
                                    : "bg-sky-600 text-white hover:bg-sky-700")
                                }
                                onClick={() =>
                                  bookAppointmentFromContent(msg.content)
                                }
                                disabled={bookingAppointment}
                              >
                                {bookingAppointment
                                  ? "Booking…"
                                  : "Book appointment"}
                              </button>
                            </div>

                            {/* Assistant message bubble itself */}
                            <MessageBubble message={msg} />
                          </div>
                        );
                      })}

                      {currentChat && streamingByChat[currentChat] && (
                        <div className="bg-white text-slate-800 text-sm p-3 rounded-2xl border border-[#D8E7F7] whitespace-pre-wrap">
                          {streamingByChat[currentChat]}
                          <span className="animate-pulse">|</span>
                        </div>
                      )}

                      {sending && !isStreaming && (
                        <div className="bg-white text-slate-500 text-sm p-3 rounded-2xl border border-[#DFE7F1] animate-pulse">
                          Thinking…
                        </div>
                      )}

                      {error && (
                        <div className="bg-rose-50 text-rose-700 text-xs p-3 rounded-xl border border-rose-200">
                          <strong className="font-semibold">Error:</strong>{" "}
                          {error}
                        </div>
                      )}

                      {suggestions.length > 0 && (
                        <div className="flex gap-2 flex-wrap mt-1">
                          {suggestions.map((s, i) => (
                            <button
                              key={i}
                              onClick={() => setInput(s)}
                              className="px-3 py-1.5 bg-white border border-[#D7E7F7] rounded-full text-[11px] text-slate-700 hover:border-sky-400 hover:bg-[#F3FAFF]"
                            >
                              {s}
                            </button>
                          ))}
                        </div>
                      )}

                      <div ref={messagesEndRef} />
                    </div>
                  </div>
                </div>

                {/* Triage alert banner */}
                {triageAlert && (
                  <div className="mt-2">
                    <div
                      className={
                        "flex items-center justify-between rounded-2xl px-3 py-2 text-xs border " +
                        (triageAlert.severity === "critical"
                          ? "bg-rose-50 border-rose-300 text-rose-800"
                          : triageAlert.severity === "medium"
                          ? "bg-amber-50 border-amber-300 text-amber-800"
                          : "bg-sky-50 border-sky-300 text-sky-800")
                      }
                    >
                      <div className="pr-3">
                        <div className="font-semibold mb-0.5">
                          {triageAlert.severity === "critical"
                            ? "⚠️ Urgent attention recommended"
                            : triageAlert.severity === "medium"
                            ? "⬆️ Follow-up advised"
                            : "ℹ️ Monitor and follow advice"}
                        </div>
                        <div className="text-[11px]">
                          Triage level:{" "}
                          <span className="font-semibold">
                            {triageAlert.triageLevel || "Not specified"}
                          </span>
                        </div>
                        {triageAlert.message && (
                          <div className="text-[11px] mt-0.5">
                            {triageAlert.message}
                          </div>
                        )}
                      </div>

                      <button
                        className={
                          "ml-2 rounded-full px-3 py-1 text-[11px] font-medium shadow-sm " +
                          (triageAlert.severity === "critical"
                            ? "bg-rose-600 text-white hover:bg-rose-700"
                            : triageAlert.severity === "medium"
                            ? "bg-amber-500 text-white hover:bg-amber-600"
                            : "bg-sky-600 text-white hover:bg-sky-700")
                        }
                        onClick={() => {
                          console.log(
                            "Book appointment clicked with triage:",
                            triageAlert
                          );
                          alert(
                            "Appointment booking triggered (wire this to your appointment API)."
                          );
                        }}
                      >
                        Book appointment
                      </button>
                    </div>
                  </div>
                )}

                {/* Attachments preview */}
                {attachedFiles.length > 0 && (
                  <div className="mt-1 flex items-center gap-2 overflow-x-auto nice-scrollbar">
                    {attachedFiles.map((f, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-2 bg-white rounded-xl px-2 py-1 text-[11px] border border-[#D7E7F7]"
                      >
                        {f.type.startsWith("image/") ? (
                          <img
                            src={URL.createObjectURL(f)}
                            alt={f.name}
                            className="w-10 h-10 rounded-lg object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500">
                            📄
                          </div>
                        )}
                        <div className="flex flex-col">
                          <span className="font-medium text-slate-800">
                            {f.name.length > 20
                              ? f.name.slice(0, 18) + "…"
                              : f.name}
                          </span>
                          <span className="text-slate-500">
                            {(f.size / 1024).toFixed(0)} KB
                          </span>
                        </div>
                        <button
                          onClick={() =>
                            setAttachedFiles((prev) =>
                              prev.filter((_, i) => i !== idx)
                            )
                          }
                          className="ml-1 text-rose-500 hover:text-rose-600"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Input bar */}
                <div className="mt-1">
                  <div className="flex items-end gap-2 rounded-2xl border border-[#D8E7F7] bg-white px-3 py-2 shadow-[0_12px_30px_rgba(15,23,42,0.08)]">
                    <textarea
                      ref={inputRef}
                      rows={1}
                      className={`flex-1 px-1.5 py-1.5 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none resize-none bg-transparent ${
                        inputRef.current && inputRef.current.scrollHeight > 160
                          ? "overflow-y-auto"
                          : "overflow-hidden"
                      }`}
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) =>
                        e.key === "Enter" &&
                        !e.shiftKey &&
                        (e.preventDefault(), sendMessage())
                      }
                      placeholder="Describe your symptoms here..."
                      disabled={sending}
                    />

                    <div className="flex items-center gap-1.5 pb-0.5">
                      <button
                        title="Attach file (e.g. photo)"
                        onClick={() => attachInputRef.current?.click()}
                        className="w-9 h-9 flex items-center justify-center rounded-full text-sky-600 hover:bg-[#E6F4FF] border border-transparent hover:border-sky-300"
                      >
                        <UploadCloud className="w-4 h-4" />
                      </button>

                      <button
                        title="Speak symptoms"
                        onClick={toggleRecording}
                        className={`w-9 h-9 flex items-center justify-center rounded-full border ${
                          recording
                            ? "border-rose-400 text-rose-500 bg-rose-50 animate-pulse"
                            : "border-transparent text-sky-600 hover:bg-[#E6F4FF] hover:border-sky-300"
                        }`}
                      >
                        <Mic className="w-4 h-4" />
                      </button>

                      {isStreaming || sending ? (
                        <button
                          onClick={stopStreaming}
                          className="w-9 h-9 rounded-full text-rose-500 border border-rose-300 flex items-center justify-center hover:bg-rose-50"
                        >
                          ✕
                        </button>
                      ) : (
                        <button
                          onClick={sendMessage}
                          className="w-10 h-10 rounded-full text-white bg-[#0077C7] hover:bg-[#0063A5] flex items-center justify-center shadow-[0_10px_24px_rgba(0,119,199,0.45)]"
                        >
                          <ArrowUpCircle className="w-5 h-5" />
                        </button>
                      )}
                    </div>
                  </div>

                  <input
                    ref={attachInputRef}
                    type="file"
                    multiple
                    accept="*"
                    className="hidden"
                    onChange={(e) => {
                      const files = e.target.files;
                      if (files && files.length > 0)
                        setAttachedFiles((prev) => [
                          ...prev,
                          ...Array.from(files),
                        ]);
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: Patient sidebar or summary */}
        <div className="mt-3 lg:mt-0 lg:w-80 lg:flex-shrink-0">
          <div className="h-full rounded-3xl bg-white border border-[#D8E7F7] shadow-[0_18px_55px_rgba(15,23,42,0.08)] px-4 py-4 flex flex-col">
            {user?.role === "clinician" && allPatients?.length > 0 ? (
              <aside className="flex-1 overflow-y-auto nice-scrollbar">
                <h2 className="text-sm font-semibold mb-2 text-slate-900">
                  Patient records
                </h2>
                {patientLoading && (
                  <div className="text-[11px] text-slate-500 mb-2">
                    Loading patients…
                  </div>
                )}
                {patientError && (
                  <div className="mb-3 text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                    {patientError}
                  </div>
                )}
                <ul className="space-y-2 text-xs">
                  {allPatients.map((p) => (
                    <li
                      key={p.email}
                      className={`border rounded-xl p-2.5 flex flex-col cursor-pointer transition-colors ${
                        selectedPatient?.email === p.email
                          ? "bg-[#E8F5FF] border-[#8BC5F5]"
                          : "bg-[#F7FBFF] border-[#DFE7F1] hover:border-sky-400 hover:bg-[#F0F7FF]"
                      }`}
                      onClick={() => handlePatientSelect(p)}
                    >
                      <span className="font-semibold text-slate-900">
                        {p.name}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        MRN: {p.mrn}
                      </span>
                      {p.active_conditions && (
                        <span className="text-[11px] text-slate-600 mt-0.5">
                          {p.active_conditions}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
                {selectedPatient && (
                  <div className="mt-4 p-3 bg-[#EAF6FF] border border-[#B4D9F7] rounded-xl text-xs">
                    <div className="font-semibold text-slate-900 mb-0.5">
                      Selected: {selectedPatient.name}
                    </div>
                    <div className="text-[11px] text-slate-600">
                      MRN: {selectedPatient.mrn}
                    </div>
                    <div className="text-[11px] text-slate-600">
                      Conditions: {selectedPatient.active_conditions}
                    </div>
                    <button
                      className="mt-2 w-full px-3 py-1.5 bg-[#0077C7] text-white rounded-full text-[11px] font-medium hover:bg-[#0063A5]"
                      onClick={() => {
                        setInput(
                          `Please provide a triage summary for ${selectedPatient.name} (${selectedPatient.mrn}) and suggest follow-up steps.`
                        );
                        setTimeout(() => sendMessage(), 80);
                      }}
                    >
                      Get triage summary
                    </button>
                  </div>
                )}
              </aside>
            ) : (
              <div className="flex-1 flex flex-col overflow-hidden text-slate-800 text-xs">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-full bg-[#0077C7] text-white flex items-center justify-center text-[11px] font-semibold">
                      {(patient?.name || user?.name || "Patient")
                        .split(" ")
                        .map((p) => p[0])
                        .slice(0, 2)
                        .join("")
                        .toUpperCase()}
                    </div>
                    <div>
                      <div className="font-semibold text-[13px] text-slate-900">
                        {patient?.name ||
                          user?.name ||
                          user?.email ||
                          "Patient"}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        MRN: {patient?.mrn ?? "—"}
                        {patient && (
                          <>
                            {" "}
                            • {patient.age} yrs • {patient.gender}
                          </>
                        )}
                      </div>
                      {patient && (
                        <div className="text-[11px] text-slate-500">
                          Primary: {patient.primary_doctor} • Last visit:{" "}
                          {patient.last_visit}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1">
                    <button className="px-3 py-1 rounded-full bg-[#0077C7] text-white text-[11px] font-medium hover:bg-[#0063A5]">
                      Message clinician
                    </button>
                    <button className="px-3 py-1 rounded-full border border-[#D5E3F3] text-[11px] text-slate-700 hover:bg-[#F4F8FE]">
                      Share
                    </button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto pr-1 nice-scrollbar">
                  {patientLoading && (
                    <div className="text-[11px] text-slate-500 mb-2">
                      Loading your health summary…
                    </div>
                  )}

                  {patientError && (
                    <div className="mb-3 text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                      {patientError}
                    </div>
                  )}

                  {!patient && !patientLoading && !patientError && (
                    <div className="text-[11px] text-slate-500">
                      No patient record was found for this login.
                    </div>
                  )}

                  {patient && (
                    <div className="space-y-4">
                      {/* Today */}
                      <section className="border border-[#DDE7F3] rounded-xl px-3.5 py-3 bg-[#F8FBFF]">
                        <h3 className="text-[12px] font-semibold text-slate-900 mb-1.5">
                          Today
                        </h3>

                        {patient.appointment_title ? (
                          <div className="mb-2">
                            <div className="text-[12px] font-semibold text-slate-900">
                              {patient.appointment_title}
                            </div>
                            <div className="text-[11px] text-slate-600">
                              {patient.appointment_date}
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {patient.appointment_location}
                            </div>
                          </div>
                        ) : (
                          <div className="text-[11px] text-slate-500 mb-2">
                            You don&apos;t have any upcoming appointments
                            booked.
                          </div>
                        )}

                        <div className="flex flex-wrap gap-2 mt-1">
                          <button className="flex-1 min-w-[110px] px-2.5 py-1.5 rounded-full bg-[#0077C7] text-[11px] text-white font-medium hover:bg-[#0063A5]">
                            Book appointment
                          </button>
                          <button className="flex-1 min-w-[110px] px-2.5 py-1.5 rounded-full bg-white text-[11px] text-slate-700 border border-[#D5E3F3] hover:bg-[#F4F8FE]">
                            Refill prescription
                          </button>
                        </div>
                      </section>

                      {/* Health snapshot */}
                      <section className="border border-[#DDE7F3] rounded-xl px-3.5 py-3 bg-[#F8FBFF]">
                        <h3 className="text-[12px] font-semibold text-slate-900 mb-1.5">
                          Health snapshot
                        </h3>

                        <div className="grid grid-cols-2 gap-y-1.5 gap-x-4 mb-2">
                          <div>
                            <div className="text-[11px] text-slate-500">
                              Heart rate
                            </div>
                            <div className="text-[12px] font-semibold text-slate-900">
                              {patient.hr} bpm
                            </div>
                          </div>
                          <div>
                            <div className="text-[11px] text-slate-500">
                              Blood pressure
                            </div>
                            <div className="text-[12px] font-semibold text-slate-900">
                              {patient.bp}
                            </div>
                          </div>
                          <div>
                            <div className="text-[11px] text-slate-500">
                              Temperature
                            </div>
                            <div className="text-[12px] font-semibold text-slate-900">
                              {patient.temp}°C
                            </div>
                          </div>
                          <div>
                            <div className="text-[11px] text-slate-500">
                              SpO₂
                            </div>
                            <div className="text-[12px] font-semibold text-slate-900">
                              {patient.spo2}%
                            </div>
                          </div>
                        </div>

                        {patient.active_conditions && (
                          <div className="mt-1">
                            <div className="text-[11px] text-slate-500 mb-0.5">
                              Active conditions
                            </div>
                            <div className="text-[11px] text-slate-800 leading-snug">
                              {patient.active_conditions}
                            </div>
                          </div>
                        )}
                      </section>

                      {/* Medications & plan */}
                      <section className="border border-[#DDE7F3] rounded-xl px-3.5 py-3 bg-[#F8FBFF]">
                        <h3 className="text-[12px] font-semibold text-slate-900 mb-1.5">
                          Medications &amp; plan
                        </h3>

                        <div className="mb-2">
                          <div className="text-[11px] text-slate-500 mb-0.5">
                            Current medications
                          </div>
                          {!patient.medication1 && !patient.medication2 && (
                            <div className="text-[11px] text-slate-500">
                              No medications recorded in your file.
                            </div>
                          )}
                          {patient.medication1 && (
                            <div className="text-[11px] text-slate-800">
                              <span className="font-semibold">
                                {patient.medication1}
                              </span>{" "}
                              {patient.medication1_dose} •{" "}
                              {patient.medication1_freq}
                            </div>
                          )}
                          {patient.medication2 && (
                            <div className="text-[11px] text-slate-800">
                              <span className="font-semibold">
                                {patient.medication2}
                              </span>{" "}
                              {patient.medication2_dose} •{" "}
                              {patient.medication2_freq}
                            </div>
                          )}
                        </div>

                        {patient.plan && (
                          <div className="mb-1">
                            <div className="text-[11px] text-slate-500 mb-0.5">
                              Plan from your clinician
                            </div>
                            <div className="text-[11px] text-slate-800 leading-snug">
                              {patient.plan}
                            </div>
                          </div>
                        )}

                        {patient.next_steps && (
                          <div className="mt-1">
                            <div className="text-[11px] text-slate-500 mb-0.5">
                              Next steps
                            </div>
                            <div className="text-[11px] text-slate-800 leading-snug">
                              {patient.next_steps}
                            </div>
                          </div>
                        )}
                      </section>

                      <p className="text-[10px] text-slate-500 mt-1">
                        This summary is based on your hospital record. If
                        something looks incorrect, please speak with your care
                        team.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* HISTORY POPUP */}
      {showHistory && (
        <div
          ref={historyContainerRef}
          style={historyStyle || undefined}
          className="popup-animate"
        >
          <div className="rounded-2xl bg-white border border-[#D8E7F7] shadow-2xl max-h-[60vh] overflow-y-auto nice-scrollbar">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[#E1E8F3]">
              <h3 className="text-sm font-semibold text-slate-900">
                Conversation history
              </h3>
              <button
                onClick={() => setShowHistory(false)}
                className="text-slate-500 text-xs hover:text-slate-800"
              >
                Close
              </button>
            </div>
            <div className="py-2">
              {chats.length === 0 && (
                <div className="px-4 py-3 text-[11px] text-slate-500">
                  No past conversations yet.
                </div>
              )}
              {chats.map((c) => (
                <div
                  key={c.id}
                  className={`flex items-start justify-between px-4 py-2 text-xs cursor-pointer hover:bg-[#F5F9FF] ${
                    currentChat === c.id ? "bg-[#EEF5FF]" : ""
                  }`}
                  onClick={() => selectHistory(c.id)}
                >
                  <div className="pr-2">
                    <div className="font-medium text-slate-900">{c.title}</div>
                    <div className="text-[11px] text-slate-500">
                      {c.messages.length} message
                      {c.messages.length === 1 ? "" : "s"}
                    </div>
                  </div>
                  <button
                    className="text-[11px] text-rose-500 hover:text-rose-600 ml-2"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteHistory(c.id);
                    }}
                  >
                    Delete
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PROFILE POPUP */}
      {showProfile && (
        <div
          ref={profileContainerRef}
          style={profileStyle || undefined}
          className="popup-animate"
        >
          <div className="rounded-2xl bg-white border border-[#D8E7F7] shadow-2xl w-72">
            <div className="px-4 py-3 border-b border-[#E1E8F3] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img
                  src={user?.picture ?? ""}
                  alt="avatar"
                  className="w-8 h-8 rounded-full object-cover bg-sky-50 border border-sky-100"
                />
                <div>
                  <div className="text-sm font-medium text-slate-900">
                    {user?.name ?? user?.email ?? "Account"}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {user?.email}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setShowProfile(false)}
                className="text-slate-500 text-xs hover:text-slate-800"
              >
                ✕
              </button>
            </div>
            <div className="px-4 py-3 text-[11px] text-slate-700 space-y-2">
              <div className="flex items-center justify-between">
                <span>Role</span>
                <span className="text-slate-900 font-medium">
                  {user?.role ?? "patient"}
                </span>
              </div>
              <button
                onClick={logout}
                className="mt-2 w-full rounded-full bg-[#E11D48] text-[11px] text-white font-medium py-1.5 hover:bg-[#BE123C]"
              >
                Sign out
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
