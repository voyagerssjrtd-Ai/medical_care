// src/components/LoginPage.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { User, Lock, Eye, EyeOff, Stethoscope, UserCircle2 } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();

  // ✅ Default to PATIENT login (since that’s what we demo now)
  const [role, setRole] = useState("patient"); // "clinician" | "patient"
  const isClinician = role === "clinician";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // simple demo creds (for future clinician path)
  const CLINICIAN_EMAIL = "clinician@careflow.ai";
  const CLINICIAN_PASSWORD = "Clinician@123";

  // Two demo patient accounts – must match DB emails
  const PATIENT_ACCOUNTS = [
    {
      email: "jasmine@careflow.ai",
      password: "Jasmine@123",
      displayName: "Jasmine",
    },
    {
      email: "swetha@careflow.ai",
      password: "Swetha@123",
      displayName: "Swetha",
    },
  ];

const handleSubmit = async (e) => {
  e.preventDefault();
  setError("");
  setLoading(true);

  try {
    const res = await fetch("http://localhost:8000/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email,
        password,
        role,
      }),
    });

    const data = await res.json();
    setLoading(false);

    if (!res.ok) {
      setError(data.detail || "Login failed");
      return;
    }

    // Store user in AuthContext
    login({
      name: data.name,
      email: data.email,
      role: data.role,
      token: data.token,
      patient_id: data.patient_id,
      clinician_id: data.clinician_id,
    });

    // Navigate based on role
    if (data.role === "clinician") {
      navigate("/clinician", { replace: true });
    } else {
      navigate("/chat", { replace: true });
    }
  } catch (err) {
    console.error(err);
    setLoading(false);
    setError("Unable to reach server.");
  }
};

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Top bar with logo + About */}
      <header className="w-full bg-cyan-100/80 border-b border-cyan-200">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-3">
          {/* Logo side */}
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-cyan-600 flex items-center justify-center">
              <span className="text-white font-bold text-lg">e+</span>
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-cyan-900 font-semibold text-sm">
                CareFlow e-Hospital
              </span>
              <span className="text-[11px] text-cyan-700">
                AI-driven symptom triage & follow-up
              </span>
            </div>
          </div>

          {/* Only About link */}
          <button
            onClick={() => navigate("/about")}
            className="text-xs font-medium text-cyan-900 hover:underline"
          >
            About
          </button>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 flex items-center justify-center">
        <div className="max-w-6xl w-full mx-auto flex flex-row items-stretch px-6 py-10 gap-10">
          {/* LEFT: hero with PNGs */}
          <div className="hidden md:flex flex-1 relative">
            <div className="relative w-full rounded-3xl bg-gradient-to-br from-cyan-100 via-sky-100 to-slate-50 overflow-hidden border border-cyan-200 shadow-sm flex items-center justify-center">
              <div className="absolute -left-10 bottom-0 w-40 h-40 bg-sky-200/70 rounded-full blur-2xl" />
              <div className="absolute -right-10 top-0 w-44 h-44 bg-cyan-200/70 rounded-full blur-2xl" />

              <div className="relative flex items-center gap-8 px-10 py-10">
                {/* Doctor / nurse PNGs */}
                <div className="flex flex-col items-center gap-4">
                  <div className="w-24 h-36 rounded-3xl bg-sky-50 border border-sky-100 shadow-sm overflow-hidden">
                    <img
                      src="/assets/doctor.png"
                      alt="Doctor"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="w-24 h-36 rounded-3xl bg-pink-50 border border-pink-100 shadow-sm overflow-hidden">
                    <img
                      src="/assets/nurse.png"
                      alt="Nurse"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                {/* Heart + ECG + stethoscope */}
                <div className="relative">
                  <div className="w-52 h-52 rounded-full bg-rose-200 shadow-lg flex items-center justify-center">
                    <div className="w-40 h-40 rounded-full bg-rose-300 flex items-center justify-center relative">
                      <svg
                        viewBox="0 0 200 80"
                        className="w-40 h-16"
                        style={{ transform: "translateY(4px)" }}
                      >
                        <polyline
                          fill="none"
                          stroke="#ffffff"
                          strokeWidth="4"
                          strokeLinejoin="round"
                          strokeLinecap="round"
                          points="0,40 30,40 40,20 55,55 75,10 95,55 115,40 140,40 160,30 180,40 200,40"
                        />
                      </svg>
                    </div>
                  </div>

                  <div className="absolute -left-10 -bottom-6">
                    <div className="w-24 h-24 rounded-full bg-cyan-500 text-white flex items-center justify-center shadow-md">
                      <Stethoscope className="w-10 h-10" />
                    </div>
                  </div>
                </div>

                {/* Text */}
                <div className="flex flex-col gap-3 max-w-xs">
                  <h2 className="text-slate-900 font-semibold text-lg">
                    AI Symptom Triage & Follow-up Planner
                  </h2>
                  <p className="text-xs text-slate-600">
                    Capture symptoms, triage urgency and generate follow-up plans
                    with an AI assistant connected to mock EHR data.
                  </p>
                  <ul className="space-y-1 text-xs text-slate-700">
                    <li>• Clinical triage console</li>
                    <li>• Patient self-reporting portal</li>
                    <li>• Personalized follow-up suggestions</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: login card */}
          <div className="w-full md:w-[360px] flex justify-center">
            <div className="w-full max-w-sm bg-white rounded-2xl shadow-lg border border-slate-200 px-7 py-8">
              {/* Logo + title */}
              <div className="flex flex-col items-center mb-6">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-9 h-9 rounded-lg bg-cyan-600 flex items-center justify-center">
                    <span className="text-white font-bold text-lg">e+</span>
                  </div>
                  <div className="flex flex-col leading-tight">
                    <span className="text-slate-900 font-semibold text-sm">
                      CareFlow e-Hospital
                    </span>
                    <span className="text-[11px] text-slate-500">
                      simplifying healthcare service delivery
                    </span>
                  </div>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Let&apos;s get started
                </p>
              </div>

              {/* Role toggle */}
              <div className="flex justify-center mb-4">
                <div className="rounded-full bg-slate-100 p-1 flex text-[11px]">
                  <button
                    type="button"
                    onClick={() => {
                      setRole("clinician");
                      setError("");
                    }}
                    className={`flex items-center gap-1 px-3 py-1 rounded-full transition ${
                      isClinician
                        ? "bg-emerald-600 text-white shadow-sm"
                        : "text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    <Stethoscope className="w-3 h-3" />
                    <span>Clinical Login</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setRole("patient");
                      setError("");
                    }}
                    className={`flex items-center gap-1 px-3 py-1 rounded-full transition ${
                      !isClinician
                        ? "bg-sky-600 text-white shadow-sm"
                        : "text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    <UserCircle2 className="w-3 h-3" />
                    <span>Patient Login</span>
                  </button>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Email */}
                <div className="relative">
                  <label className="block text-xs text-slate-600 mb-1">
                    {isClinician ? "Username / Work Email" : "Email"}
                  </label>
                  <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2 border border-slate-200 focus-within:ring-2 focus-within:ring-cyan-100">
                    <User size={16} className="text-slate-400" />
                    <input
                      value={email}
                      onChange={(e) => setEmail(e.target.value.trim())}
                      type="email"
                      placeholder={
                        isClinician
                          ? CLINICIAN_EMAIL
                          : "jasmine@careflow.ai or swetha@careflow.ai"
                      }
                      className="bg-transparent outline-none w-full text-slate-900 placeholder:text-slate-400 text-sm"
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="relative">
                  <label className="block text-xs text-slate-600 mb-1">
                    Password
                  </label>
                  <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2 border border-slate-200 focus-within:ring-2 focus-within:ring-cyan-100 relative">
                    <Lock size={16} className="text-slate-400" />
                    <input
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      type={passwordVisible ? "text" : "password"}
                      placeholder="••••••••"
                      className="bg-transparent outline-none w-full text-slate-900 placeholder:text-slate-400 text-sm pr-8"
                    />
                    <button
                      type="button"
                      onClick={() => setPasswordVisible((v) => !v)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500"
                    >
                      {passwordVisible ? <EyeOff size={17} /> : <Eye size={17} />}
                    </button>
                  </div>
                </div>

                {/* Error */}
                {error && (
                  <div className="text-rose-500 text-xs mt-1">{error}</div>
                )}

                {/* Sign in */}
                <button
                  type="submit"
                  className={`w-full mt-1 py-2.5 rounded-full text-white text-sm font-semibold shadow-md flex items-center justify-center gap-2 transition-colors ${
                    isClinician
                      ? "bg-emerald-600 hover:bg-emerald-700"
                      : "bg-sky-600 hover:bg-sky-700"
                  }`}
                >
                  {loading ? (
                    <span
                      style={{
                        width: 18,
                        height: 18,
                        border: "2px solid rgba(255,255,255,0.45)",
                        borderTop: "2px solid rgba(255,255,255,1)",
                        borderRadius: 999,
                      }}
                      className="animate-spin"
                    />
                  ) : (
                    <span>Sign in</span>
                  )}
                </button>

                {/* Options */}
                <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
                  <label className="flex items-center gap-1">
                    <input type="checkbox" className="accent-cyan-600" />
                    <span>Keep me signed in</span>
                  </label>
                  <button
                    type="button"
                    className="text-cyan-700 hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>
              </form>

              {/* Footer note */}
              <p className="mt-6 text-center text-[11px] text-slate-400 leading-snug">
                As per cyber security guidelines, users should update their
                passwords periodically. Contact your hospital admin for access
                or reset assistance.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
