// Frontend/src/components/ClinicianDashboard.jsx

import React, { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useNavigate, Navigate } from "react-router-dom";
import {
  Stethoscope,
  Users,
  MessageSquare,
  CalendarClock,
  ClipboardList,
  Activity,
  AlertTriangle,
  BrainCircuit,
  FileText,
  BarChart3,
  ShieldCheck,
  Settings2,
  Inbox,
  ListChecks,
} from "lucide-react";

export default function ClinicianDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState("overview");

  // ✅ NEW: overview data from backend
  const [overview, setOverview] = useState(null);
  const [loadingOverview, setLoadingOverview] = useState(false);
  const [overviewError, setOverviewError] = useState(null);

  // 🔒 Route protection – only clinicians allowed
  if (!user || user.role !== "clinician") {
    return <Navigate to="/" replace />;
  }

  useEffect(() => {
    const fetchOverview = async () => {
      setLoadingOverview(true);
      setOverviewError(null);
      try {
        const res = await fetch("http://localhost:8000/clinician/overview");
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        setOverview(data);
      } catch (err) {
        console.error("Failed to load clinician overview", err);
        setOverviewError(
          err?.message || "Unable to load clinician overview data."
        );
      } finally {
        setLoadingOverview(false);
      }
    };

    fetchOverview();
  }, []);

  const renderSectionTitle = () => {
    switch (activeSection) {
      case "overview":
        return "Clinical overview";
      case "triage-queue":
        return "Symptom triage queue";
      case "ai-workspace":
        return "AI triage workspace";
      case "followup":
        return "Follow-up planner";
      case "patients":
        return "Patients & cohorts";
      case "appointments":
        return "Appointments & calendar";
      case "analytics":
        return "Quality & performance metrics";
      case "audit":
        return "Audit trail & safety";
      case "settings":
        return "Settings & integrations";
      default:
        return "Clinical overview";
    }
  };

  const isOverview = activeSection === "overview";

  // 👉 convenient local variables with safe fallbacks
  const triageStats = overview?.triage_stats || {
    open_cases: 0,
    high_risk: 0,
    awaiting_review: 0,
    followups_today: 0,
  };

  const triageQueue = overview?.triage_queue || [];
  const followUps = overview?.followups || [];
  const aiSessions = overview?.ai_sessions || [];
  const systemHealth = overview?.system_health || {
    llm_latency_ms: 0,
    api_error_rate: "0%",
    active_agents: 0,
    ehr_latency_ms: 0,
  };

  return (
    <div className="h-screen flex bg-slate-100 text-slate-900">
      {/* Sidebar */}
      <aside className="w-72 bg-slate-900 text-slate-50 flex flex-col shadow-xl">
        {/* App brand */}
        <div className="px-5 pt-5 pb-4 border-b border-slate-800 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-cyan-500 flex items-center justify-center">
            <span className="text-sm font-bold text-white">e+</span>
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold">CareFlow e-Hospital</div>
            <div className="text-[11px] text-slate-300">
              Clinician control center
            </div>
          </div>
        </div>

        {/* Nav sections */}
        <nav className="flex-1 overflow-auto px-3 py-4 space-y-4 text-sm">
          <div>
            <div className="px-2 text-[11px] uppercase tracking-wide text-slate-500 mb-1">
              Symptom triage
            </div>
            <button
              onClick={() => setActiveSection("overview")}
              className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg transition ${
                activeSection === "overview"
                  ? "bg-slate-800 text-white"
                  : "text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>Dashboard overview</span>
            </button>

            <button
              onClick={() => setActiveSection("triage-queue")}
              className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg transition ${
                activeSection === "triage-queue"
                  ? "bg-slate-800 text-white"
                  : "text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <Inbox className="w-4 h-4" />
              <span>Symptom triage queue</span>
            </button>

            <button
              onClick={() => {
                setActiveSection("ai-workspace");
                navigate(
  `/chat?patient=${encodeURIComponent(p.email)}&autotriage=true`
);
              }}
              className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-slate-200 hover:bg-slate-800/60 transition"
            >
              <BrainCircuit className="w-4 h-4" />
              <span>AI triage workspace</span>
            </button>

            <button
              onClick={() => setActiveSection("followup")}
              className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg transition ${
                activeSection === "followup"
                  ? "bg-slate-800 text-white"
                  : "text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <ClipboardList className="w-4 h-4" />
              <span>Follow-up planner</span>
            </button>
          </div>

          <div>
            <div className="px-2 text-[11px] uppercase tracking-wide text-slate-500 mb-1">
              Records & tasks
            </div>

            <button
              onClick={() => setActiveSection("patients")}
              className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg transition ${
                activeSection === "patients"
                  ? "bg-slate-800 text-white"
                  : "text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Patients & cohorts</span>
            </button>

            <button
              onClick={() => setActiveSection("appointments")}
              className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg transition ${
                activeSection === "appointments"
                  ? "bg-slate-800 text-white"
                  : "text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <CalendarClock className="w-4 h-4" />
              <span>Appointments & calendar</span>
            </button>
          </div>

          <div>
            <div className="px-2 text-[11px] uppercase tracking-wide text-slate-500 mb-1">
              Safety & insights
            </div>

            <button
              onClick={() => setActiveSection("analytics")}
              className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg transition ${
                activeSection === "analytics"
                  ? "bg-slate-800 text-white"
                  : "text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Quality & performance</span>
            </button>

            <button
              onClick={() => setActiveSection("audit")}
              className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg transition ${
                activeSection === "audit"
                  ? "bg-slate-800 text-white"
                  : "text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Audit trail & safety</span>
            </button>

            <button
              onClick={() => setActiveSection("settings")}
              className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg transition ${
                activeSection === "settings"
                  ? "bg-slate-800 text-white"
                  : "text-slate-200 hover:bg-slate-800/60"
              }`}
            >
              <Settings2 className="w-4 h-4" />
              <span>Settings & integrations</span>
            </button>
          </div>
        </nav>

        {/* Bottom clinician info + logout */}
        <div className="border-t border-slate-800 px-4 py-3 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center">
              <Stethoscope className="w-4 h-4 text-cyan-300" />
            </div>
            <div className="leading-tight">
              <div className="font-medium text-slate-50 truncate">
                {user.name ?? "Clinician"}
              </div>
              <div className="text-[11px] text-slate-400 truncate">
                {user.email}
              </div>
            </div>
          </div>
          <button
            onClick={logout}
            className="text-rose-400 hover:text-rose-300 font-medium"
          >
            Logout
          </button>
        </div>
      </aside>

      {/* Main area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="px-8 py-4 border-b border-slate-200 bg-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-cyan-100 flex items-center justify-center">
              <Stethoscope className="w-5 h-5 text-cyan-700" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                {renderSectionTitle()}
                <span className="text-[11px] font-normal text-slate-500 border border-slate-200 rounded-full px-2 py-[2px]">
                  AI-driven triage & follow-up
                </span>
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Logged in as {user.name}. Data below is loaded from the clinical
                SQLite backend.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/chat")}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-full bg-cyan-600 text-white text-xs font-semibold hover:bg-cyan-700 shadow-sm"
            >
              <BrainCircuit className="w-4 h-4" />
              <span>Open AI triage workspace</span>
            </button>
          </div>
        </header>

        {/* Content */}
        <section className="flex-1 overflow-auto px-8 py-6">
          {isOverview ? (
            <>
              {loadingOverview && (
                <div className="text-sm text-slate-500">
                  Loading clinical overview…
                </div>
              )}

              {overviewError && !loadingOverview && (
                <div className="mb-4 text-xs text-rose-700 bg-rose-50 border border-rose-100 rounded-lg px-3 py-2">
                  {overviewError}
                </div>
              )}

              {!loadingOverview && !overviewError && (
                <div className="space-y-6">
                  {/* Stats row */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col gap-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-500">
                          Open triage cases
                        </span>
                        <Inbox className="w-4 h-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-semibold text-slate-900">
                        {triageStats.open_cases}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Patients awaiting AI + clinician review
                      </p>
                    </div>

                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col gap-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-500">
                          High-risk alerts
                        </span>
                        <AlertTriangle className="w-4 h-4 text-amber-500" />
                      </div>
                      <div className="text-2xl font-semibold text-amber-600">
                        {triageStats.high_risk}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Marked as urgent based on symptom patterns
                      </p>
                    </div>

                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col gap-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-500">
                          Awaiting clinician review
                        </span>
                        <FileText className="w-4 h-4 text-slate-400" />
                      </div>
                      <div className="text-2xl font-semibold text-slate-900">
                        {triageStats.awaiting_review}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        AI drafts ready for confirmation
                      </p>
                    </div>

                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col gap-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-500">
                          Follow-ups today
                        </span>
                        <ListChecks className="w-4 h-4 text-emerald-500" />
                      </div>
                      <div className="text-2xl font-semibold text-emerald-600">
                        {triageStats.followups_today}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Planned check-ins & care plan reviews
                      </p>
                    </div>
                  </div>

                  {/* Middle: triage queue & followups */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Triage queue */}
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-sm font-semibold flex items-center gap-2">
                            <Inbox className="w-4 h-4 text-slate-500" />
                            Live symptom triage queue
                          </div>
                          <p className="text-[11px] text-slate-500">
                            Derived from your SQLite patient records.
                          </p>
                        </div>
                      </div>

                      <div className="space-y-2 text-xs">
                        {triageQueue.length === 0 && (
                          <div className="text-[11px] text-slate-500">
                            No active triage cases found in the database.
                          </div>
                        )}
                        {triageQueue.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between px-3 py-2 rounded-lg border border-slate-100 hover:bg-slate-50"
                          >
                            <div>
                              <div className="font-medium text-slate-900">
                                {item.name}
                                <span className="text-[10px] text-slate-500 ml-1">
                                  • {item.id}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-600">
                                {item.reason}
                              </div>
                            </div>
                            <div className="flex flex-col items-end gap-1">
                              <span
                                className={`text-[10px] px-2 py-[2px] rounded-full ${
                                  item.severity === "High"
                                    ? "bg-rose-50 text-rose-600 border border-rose-100"
                                    : item.severity === "Medium"
                                    ? "bg-amber-50 text-amber-700 border border-amber-100"
                                    : "bg-emerald-50 text-emerald-700 border border-emerald-100"
                                }`}
                              >
                                {item.severity} risk
                              </span>
                              <span className="text-[10px] text-slate-500">
                                Waiting {item.waiting}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Follow-up planner */}
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-sm font-semibold flex items-center gap-2">
                            <ClipboardList className="w-4 h-4 text-slate-500" />
                            Follow-up planner
                          </div>
                          <p className="text-[11px] text-slate-500">
                            Upcoming follow-ups from patient records.
                          </p>
                        </div>
                      </div>

                      <div className="space-y-2 text-xs">
                        {followUps.length === 0 && (
                          <div className="text-[11px] text-slate-500">
                            No follow-ups found in the database.
                          </div>
                        )}
                        {followUps.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between px-3 py-2 rounded-lg border border-slate-100 hover:bg-slate-50"
                          >
                            <div>
                              <div className="font-medium text-slate-900">
                                {item.name}
                                <span className="text-[10px] text-slate-500 ml-1">
                                  • {item.type}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-600">
                                {item.due}
                              </div>
                            </div>
                            <button className="text-[11px] text-cyan-700 hover:underline">
                              Open
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Bottom: AI sessions & system health */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* AI sessions */}
                    <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-sm font-semibold flex items-center gap-2">
                            <MessageSquare className="w-4 h-4 text-slate-500" />
                            Recent AI triage sessions
                          </div>
                          <p className="text-[11px] text-slate-500">
                            You can later back this with chat logs in SQLite or DuckDB.
                          </p>
                        </div>
                      </div>

                      <div className="space-y-2 text-xs">
                        {aiSessions.length === 0 && (
                          <div className="text-[11px] text-slate-500">
                            No AI session metadata wired up yet.
                          </div>
                        )}
                        {aiSessions.map((s) => (
                          <div
                            key={s.id}
                            className="flex items-center justify-between px-3 py-2 rounded-lg border border-slate-100 hover:bg-slate-50"
                          >
                            <div>
                              <div className="font-medium text-slate-900">
                                {s.title}
                              </div>
                              <div className="text-[11px] text-slate-600">
                                {s.when}
                              </div>
                            </div>
                            <span
                              className={`text-[10px] px-2 py-[2px] rounded-full ${
                                s.status === "Completed"
                                  ? "bg-emerald-50 text-emerald-700 border border-emerald-100"
                                  : "bg-amber-50 text-amber-700 border border-amber-100"
                              }`}
                            >
                              {s.status}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* System health */}
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-sm font-semibold flex items-center gap-2">
                            <BarChart3 className="w-4 h-4 text-slate-500" />
                            System health & safety
                          </div>
                          <p className="text-[11px] text-slate-500">
                            Wire this to real metrics or logs if you track them.
                          </p>
                        </div>
                      </div>

                      <div className="space-y-3 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">
                            LLM avg latency
                          </span>
                          <span className="font-medium text-slate-900">
                            {systemHealth.llm_latency_ms} ms
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">
                            API error rate
                          </span>
                          <span className="font-medium text-amber-700">
                            {systemHealth.api_error_rate}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">
                            Active AI agents
                          </span>
                          <span className="font-medium text-slate-900">
                            {systemHealth.active_agents}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">
                            EHR response time
                          </span>
                          <span className="font-medium text-slate-900">
                            {systemHealth.ehr_latency_ms} ms
                          </span>
                        </div>
                      </div>

                      <div className="mt-4 flex items-center gap-2 text-[11px] text-slate-500">
                        <ShieldCheck className="w-4 h-4 text-emerald-500" />
                        <span>
                          Audit logging can be stored in SQLite / DuckDB for
                          every triage & follow-up decision.
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          ) : (
            // Simple placeholder for non-overview sections
            <div className="h-full flex flex-col items-center justify-center text-center text-sm text-slate-500">
              <div className="mb-2">
                <Stethoscope className="w-8 h-8 mx-auto text-slate-300" />
              </div>
              <p className="font-medium text-slate-700 mb-1">
                {renderSectionTitle()}
              </p>
              <p className="max-w-md text-xs text-slate-500">
                This section can be wired to additional backend endpoints
                (e.g., /clinician/triage-queue, /clinician/patients) using the
                same pattern as the overview.
              </p>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
