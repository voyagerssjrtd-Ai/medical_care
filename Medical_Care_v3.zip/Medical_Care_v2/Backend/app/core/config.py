from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment or .env file.

    The Azure MaaS fields are optional for local development and tests, so we
    provide empty-string defaults. In deployed environments you should override
    these via environment variables or a .env file.
    """

    azure_maas_base_url: str = ""
    azure_maas_api_key: str = ""

    sqlite_path: str = str(
        Path(__file__).resolve().parents[2] / "data" / "inventory.db"
    )

    class Config:
        env_file = ".env"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
