"""HTTP API for the AI-powered patient triage and clinician tools."""

# Backend/app/main.py
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from Backend.graph.router_graph import graph
import sqlite3
from pathlib import Path

from Backend.app.core.config import get_settings
from Backend.app.core.logging import configure_logging
from Backend.app.core.errors import (
    ExternalServiceError,
    external_service_error_handler,
    validation_exception_handler,
)
from fastapi.exceptions import RequestValidationError
from Backend.app.api import files as files_api
from Backend.app.api import appointment as appointment_api
from Backend.app.api import guardrails as guardrails_api
from Backend.app.api import workflow as workflow_api
from Backend.app.services.triage_service import run_triage
from Backend.app.models.triage import SymptomTriageRequest, SymptomTriageResponse

configure_logging()
settings = get_settings()

app = FastAPI(title="AI Patient Triage API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin] if hasattr(settings, "frontend_origin") else ["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_exception_handler(ExternalServiceError, external_service_error_handler)
app.add_exception_handler(RequestValidationError, validation_exception_handler)


class ChatRequest(BaseModel):
    """Generic chat payload used by the existing /chat endpoint."""

    message: str


# --- helper for DB connection ---
DB_PATH = Path(__file__).resolve().parent.parent / "data" / "inventory.db"

def get_db_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# --- Helper: get current user type and email (stub, replace with real auth) ---
def get_current_user(request: Request):
    # In production, use real authentication/session/cookie/JWT
    # Here, use query params for demo: ?user_type=clinician or ?user_type=patient&email=...
    user_type = request.query_params.get("user_type", "patient")
    email = request.query_params.get("email")
    return user_type, email

# --------------- Routers -----------------

app.include_router(files_api.router)
app.include_router(appointment_api.router)
app.include_router(guardrails_api.router)
app.include_router(workflow_api.router)


# --------------- CHAT / LLM -----------------
@app.post("/chat")
async def chat(req: ChatRequest):
    state = {"input_text": req.message}
    try:
        result = graph.invoke(state)
        # langgraph returns merged dict; output key is the final assistant text
        return {
            "response": result.get("output") or "No response produced",
            "meta": {
                "intent": result.get("intent"),
                "agent": result.get("target_agent"),
            },
        }
    except Exception as e:
        return {"response": f"❌ Error invoking graph: {e}"}


# --------------- SYMPTOM TRIAGE (production-facing) -----------------
@app.post("/triage", response_model=SymptomTriageResponse)
async def triage(req: SymptomTriageRequest) -> SymptomTriageResponse:
    """Main AI triage endpoint.

    Delegates to the `run_triage` service which coordinates RAG + EHR
    context and converts the result into a normalized response model.
    """

    return run_triage(
        symptoms=req.symptoms,
        patient_email=req.patient_email,
        additional_context=req.additional_context,
    )

# --------------- PATIENT SUMMARY (already used by Chat UI) -----------------
@app.get("/patient/{email}")
def get_patient_summary(email: str):
    conn = get_db_conn()
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM patients WHERE email = ?", (email,))
        row = cur.fetchone()
    finally:
        conn.close()

    if not row:
        raise HTTPException(status_code=404, detail="Patient not found")

    return dict(row)

# --------------- CLINICIAN OVERVIEW (NEW) -----------------
@app.get("/clinician/overview")
def clinician_overview():
    """
    Overview data for the clinician dashboard.

    Uses the existing `patients` table, which already stores:
    - demographics (name, email, age, gender, mrn, primary_doctor, last_visit)
    - vitals (hr, bp, temp, spo2)
    - appointments (appointment_title, appointment_date, appointment_location)
    - care plan (active_conditions, plan, next_steps, etc.)
    """
    conn = get_db_conn()
    try:
        cur = conn.cursor()
        # Pull key fields from the patients table
        cur.execute(
            """
            SELECT
                id,
                name,
                email,
                COALESCE(active_conditions, '') AS active_conditions,
                COALESCE(appointment_title, '') AS appointment_title,
                COALESCE(appointment_date, '') AS appointment_date,
                COALESCE(appointment_location, '') AS appointment_location,
                COALESCE(plan, '') AS plan,
                COALESCE(next_steps, '') AS next_steps
            FROM patients
            """
        )
        rows = cur.fetchall()
    finally:
        conn.close()

    patients = [dict(r) for r in rows]

    # ---------- Build triage queue from patient records ----------
    triage_queue = []
    for p in patients:
        reason = p.get("active_conditions") or p.get("plan") or "Symptom update"
        txt = (reason or "").lower()

        # Simple keyword-based severity for demo
        if any(k in txt for k in ["chest", "breath", "shortness of breath", "severe"]):
            severity = "High"
        elif any(k in txt for k in ["fever", "cough", "infection", "pain"]):
            severity = "Medium"
        else:
            severity = "Low"

        triage_queue.append(
            {
                "id": f"T-{p['id']}",
                "name": p["name"],
                "severity": severity,
                "reason": reason,
                # For now, a static placeholder; you can add created_at to patients later
                "waiting": "10 min",
            }
        )

    # ---------- Build follow-up items from appointments / next_steps ----------
    followups = []
    for p in patients:
        has_appointment = bool(p.get("appointment_date"))
        has_next_steps = bool(p.get("next_steps"))

        if not (has_appointment or has_next_steps):
            continue

        followups.append(
            {
                "id": f"F-{p['id']}",
                "name": p["name"],
                "type": p.get("appointment_title") or "Care plan follow-up",
                # combine appointment date + location or fall back to next_steps text
                "due": (
                    f"{p['appointment_date']} @ {p['appointment_location']}"
                    if p.get("appointment_date")
                    else p.get("next_steps") or "No date set"
                ),
            }
        )

    # ---------- Aggregate triage stats ----------
    high_risk = sum(1 for t in triage_queue if t["severity"] == "High")
    awaiting_review = len(triage_queue)  # can be refined later
    followups_today = len(followups)     # also can be refined by date

    triage_stats = {
        "open_cases": len(triage_queue),
        "high_risk": high_risk,
        "awaiting_review": awaiting_review,
        "followups_today": followups_today,
    }

    # ---------- Stub: recent AI sessions (later you can log chats here) ----------
    ai_sessions = [
        {
            "id": "S-9001",
            "title": "Chest pain triage",
            "when": "10 min ago",
            "status": "Completed",
        },
        {
            "id": "S-9002",
            "title": "Fever & cough triage",
            "when": "35 min ago",
            "status": "In review",
        },
    ]

    # ---------- Stub: system health metrics ----------
    system_health = {
        "llm_latency_ms": 830,
        "api_error_rate": "0.9%",
        "active_agents": 3,
        "ehr_latency_ms": 210,
    }

    return {
        "triage_stats": triage_stats,
        "triage_queue": triage_queue,
        "followups": followups,
        "ai_sessions": ai_sessions,
        "system_health": system_health,
    }

@app.get("/patients")
def get_patients(request: Request):
    user_type, email = get_current_user(request)
    conn = get_db_conn()
    try:
        cur = conn.cursor()
        if user_type == "clinician":
            cur.execute("SELECT * FROM patients")
            rows = cur.fetchall()
            return [dict(r) for r in rows]
        elif user_type == "patient" and email:
            cur.execute("SELECT * FROM patients WHERE email = ?", (email,))
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Patient not found")
            return dict(row)
        else:
            raise HTTPException(status_code=400, detail="Invalid user context")
    finally:
        conn.close()


app.include_router(files_api.router)

@app.get("/")
def root():
    return {"status": "running"}
