from pydantic import BaseModel
from typing import List, Optional


class SymptomTriageRequest(BaseModel):
    """Structured payload for triage-specific calls."""

    symptoms: str
    patient_email: Optional[str] = None
    additional_context: Optional[str] = None


class FollowUpPlan(BaseModel):
    """Represents a simple, patient-friendly follow-up plan."""

    triage_level: str
    recommendations: List[str]
    follow_up_timeline: Optional[str] = None
    escalation_warning: Optional[str] = None


class SymptomTriageResponse(BaseModel):
    """Normalized response for the AI-driven triage endpoint."""

    summary: str
    follow_up_plan: FollowUpPlan
    raw_model_output: Optional[str] = None
    intent: Optional[str] = None
    target_agent: Optional[str] = None
