import logging
from typing import List, Optional

from pydantic import BaseModel

from Backend.app.services.triage_service import run_triage, SymptomTriageResponse
from Backend.app.services.appointment_service import (
    AppointmentRequest,
    AppointmentResponse,
    book_appointment,
)
from Backend.app.services.guardrails_service import (
    GuardrailsResponse,
    run_guardrails,
)


logger = logging.getLogger(__name__)


class TriageAppointmentRequest(BaseModel):
    patient_id: str
    symptoms: str
    preferred_times: Optional[List[str]] = None


class TriageAppointmentResponse(BaseModel):
    triage: SymptomTriageResponse
    guardrails: GuardrailsResponse
    appointment: AppointmentResponse


def run_triage_plus_appointment(req: TriageAppointmentRequest) -> TriageAppointmentResponse:
    """Orchestrate triage, guardrails, and appointment suggestion.

    This is a lightweight replacement for the legacy workflow.graph
    that uses the new triage, guardrails, and appointment services.
    """

    logger.info(
        "workflow_triage_plus_appointment_started",
        extra={"patient_id": req.patient_id},
    )

    triage = run_triage(req.symptoms, patient_email=req.patient_id)

    # Instead of triage.follow_up_plan.reasoning, use triage.summary for guardrails
    guardrails = run_guardrails(triage.summary)

    appointment_req = AppointmentRequest(
        patient_id=req.patient_id,
        symptoms=req.symptoms,
        triage_level=triage.follow_up_plan.triage_level,
        preferred_times=req.preferred_times,
    )
    appointment = book_appointment(appointment_req)

    logger.info(
        "workflow_triage_plus_appointment_completed",
        extra={"patient_id": req.patient_id},
    )

    return TriageAppointmentResponse(
        triage=triage,
        guardrails=guardrails,
        appointment=appointment,
    )
