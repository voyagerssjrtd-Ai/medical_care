import logging
from typing import List, Optional

from pydantic import BaseModel

from Backend.agents.appointment_agent import (
    appointment_book_agent,
    AppointmentState,
)


logger = logging.getLogger(__name__)


class AppointmentRequest(BaseModel):
    patient_id: str
    symptoms: Optional[str] = None
    triage_level: Optional[str] = None
    preferred_times: Optional[List[str]] = None


class AppointmentResponse(BaseModel):
    message: str


def book_appointment(req: AppointmentRequest) -> AppointmentResponse:
    """Invoke the appointment agent with logging and a stable response model."""

    state: AppointmentState = {
        "patient_id": req.patient_id,
        "symptoms": req.symptoms or "",
        "triage_level": req.triage_level or "",
        "preferred_times": req.preferred_times or [],
    }

    logger.info(
        "appointment_book_started",
        extra={
            "patient_id": req.patient_id,
            "triage_level": req.triage_level or "",
        },
    )

    state = appointment_book_agent(state)

    logger.info(
        "appointment_book_completed",
        extra={"patient_id": req.patient_id},
    )

    return AppointmentResponse(message=state.get("output", "No output produced"))
