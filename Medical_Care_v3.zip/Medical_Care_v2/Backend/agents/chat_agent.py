import sys
import os
sys.path.append(str(os.path.dirname(os.path.dirname(__file__))))
from azure_llm import getMassGpt
from loader import json_to_text, get_patient_by_id, load_jsons
from chunking import getRetriever
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from Backend.agents.db_agent import get_patient_by_email, get_all_patients


retriever = None
llm = getMassGpt()


def chat_query_agent(state: dict) -> dict:
    """RAG-powered agent that answers clinical queries using docs + EHR.

    This is adapted from the original root-level `chat_agent.py` but moved
    into the Backend/agents package so it can be reused by the triage
    service and LangGraph workflows.
    """

    global retriever

    user_query = state["query"]

    # Try to extract patient MRN or name from the query (simple heuristic)
    import re
    mrn_match = re.search(r"\bP\d{3}\b", user_query)
    name_match = re.search(r"for ([A-Za-z ]+) \(P\d{3}\)", user_query)
    patient_record_json = None
    if mrn_match:
        patient_record_json = get_patient_by_id(mrn_match.group(0))
    elif name_match:
        # Try to match by name if MRN not found
        name = name_match.group(1).strip()
        ehr_data = load_jsons()
        for patient in ehr_data.get("patients", []):
            if patient.get("name", "").lower() == name.lower():
                patient_record_json = patient
                break
    else:
        # fallback: first patient
        ehr_data = load_jsons()
        if ehr_data.get("patients"):
            patient_record_json = ehr_data["patients"][0]

    # Log the resolved patient record for debugging (pretty-print for clarity)
    import json as _json
    print(f"[DEBUG] Resolved patient record for query '{user_query}':\n" + _json.dumps(patient_record_json, indent=2, ensure_ascii=False))

    # Format patient record for prompt
    patient_record_text = json_to_text(patient_record_json) if patient_record_json else None
    patient_record = (
        "Patient Past Record:\n" + "\n".join(patient_record_text)
        if patient_record_text
        else "No past record found."
    )

    qa_prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "You are a helpful medical assistant. Answer questions using only the provided context. "
                "If the answer is not in the context, say you don't know rather than making up information.",
            ),
            (
                "human",
                '''You are given the patient's past medical records and the retrieved context from relevant documents.

Context (retrieved from vector database):
{context}

Patient Past Record:
{patient_record}

Current patient query / symptom:
{question}

Guidelines:
1. Use ONLY the information from the retrieved context and patient past record.
2. Synthesize both sources to provide a clear, concise, and personalized response for THIS patient. Do NOT use a generic template.
3. Do NOT invent facts not present in the context or past record.
4. Provide your response in the following structured format:

    - **Triage Level**: [Low / Medium / High / Emergency]
    - **Reasoning**: [Explain why this triage level is assigned, referencing specific details from the patient record and context]
    - **Urgent Evaluation Needed**: [Yes/No; specify tests if any]
    - **Patient Actions**: [What patient should do next]
    - **Clinician Tasks**: [Tasks clinician should perform]
    - **Disclaimer**: [Include standard medical disclaimer]

5. If the context and past record do not contain the answer, respond:
    "The provided documents do not contain information about this."

---

Example:

Patient Past Record:
- Name: John Smith (P123)
- Age: 54
- Sex: Male
- Past Medical History: Hypertension, Type 2 Diabetes
- Medications: Lisinopril, Metformin
- Allergies: Penicillin
- Last Visit: 2025-10-12 (complaint: chest pain, EKG normal)

Context (retrieved from vector database):
"Recent studies show that patients with diabetes and hypertension are at increased risk for cardiac events."

Current patient query / symptom:
"I have been experiencing shortness of breath and mild chest discomfort today."

Sample Response:
- **Triage Level**: High
- **Reasoning**: The patient has a history of hypertension and diabetes, both risk factors for cardiac disease. The current symptoms of shortness of breath and chest discomfort raise concern for possible cardiac ischemia, especially given the recent complaint of chest pain. Although the last EKG was normal, new symptoms warrant prompt evaluation.
- **Urgent Evaluation Needed**: Yes; recommend EKG, cardiac enzymes, and immediate clinical assessment.
- **Patient Actions**: Go to the nearest emergency department immediately.
- **Clinician Tasks**: Perform EKG, order cardiac enzymes, monitor vitals, and consider cardiology consult.
- **Disclaimer**: This summary is for informational purposes only and does not constitute medical advice. Please consult a healthcare professional for diagnosis and treatment.

---

Now, answer for the current patient and query using the same format and level of detail.''',
            ),
        ]
    )

    if retriever is None:
        # Lazy initialisation so that importing this module does not trigger LLM calls
        # via chunking.getRetriever(), which is important in environments without
        # outbound LLM access.
        retriever = getRetriever()

    rag_chain = (
        {
            "context": retriever,
            "patient_record": lambda _: patient_record,
            "question": RunnablePassthrough(),
        }
        | qa_prompt
        | llm
    )

    resp = rag_chain.invoke(user_query)
    state["output"] = resp.content
    return state