import json
import re
from datetime import datetime, timedelta
from typing import Any, Dict, TypedDict

from langchain_core.messages import HumanMessage

from azure_llm import getMassGpt


class AppointmentState(TypedDict, total=False):
    """State container for the appointment booking agent.

    This mirrors the legacy appointment agent state while living inside the
    Backend package. Additional keys may be added by downstream agents.
    """

    query: str
    kind: str
    doctor_name: str
    specialty: str
    department: str
    test: str
    disease: str
    service: str
    date: str
    time: str
    location: str
    preferred_start: str
    output: str


llm = getMassGpt()


def _extract_entities(query: str) -> Dict[str, Any]:
    """Call LLM to extract structured entities from the query.

    This is a direct adaptation of your legacy helper. It asks the LLM to
    return *only* JSON, then attempts to parse it. On failure it returns an
    empty dict so the caller can fall back gracefully.
    """

    raw_entities_msg = llm.invoke(
        [
            HumanMessage(
                content=(
                    """
                    Extract entities from this appointment request.
                    Return ONLY valid JSON, no extra text, no explanations.
                    Keys: type (doctor/lab/disease/service), doctor_name, specialty, department,
                          test, disease, service, date, time, location.
                    Rules:
                    - If no date is mentioned, set "date" to "tomorrow".
                    - If no time is mentioned, set "time" to "09:00".
                    Input: "{query}"
                    """
                )
            )
        ]
    )
    raw_text = str(raw_entities_msg.content).strip()
    match = re.search(r"\{.*\}", raw_text, re.DOTALL)
    if match:
        raw_text = match.group(0)

    try:
        return json.loads(raw_text)
    except Exception:
        # In non-LLM or RBAC-restricted environments this will likely fail;
        # return an empty dict so the caller can still proceed.
        return {}


def _normalize_date(date_str: str | None) -> str:
    """Normalize date string to YYYY-MM-DD, default to tomorrow."""

    if not date_str or date_str.lower() == "tomorrow":
        return (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").strftime("%Y-%m-%d")
    except Exception:
        return (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")


def _normalize_time(time_str: str | None) -> str:
    """Normalize time string, default to 09:00."""

    return time_str or "09:00"


def appointment_book_agent(state: AppointmentState) -> AppointmentState:
    """Main appointment booking agent using the LLM for entity extraction.

    Expects `state["query"]` to contain the user's natural-language
    appointment request. It augments the state with parsed entities and a
    `preferred_start` timestamp string. Downstream routing (doctor/lab/etc.)
    can be added later using these fields.
    """

    query = state.get("query", "") or ""

    entities = _extract_entities(query)
    parsed_date = _normalize_date(entities.get("date"))
    time_str = _normalize_time(entities.get("time"))

    # Update state with extracted values
    state.update(
        {
            "kind": entities.get("type"),
            "doctor_name": entities.get("doctor_name"),
            "specialty": entities.get("specialty"),
            "department": entities.get("department"),
            "test": entities.get("test"),
            "disease": entities.get("disease"),
            "service": entities.get("service"),
            "date": parsed_date,
            "time": time_str,
            "location": entities.get("location"),
            "preferred_start": f"{parsed_date} {time_str}",
        }
    )

    # For now, just echo a simple confirmation into `output`. You can
    # re-introduce per-kind routing (doctor/lab/etc.) once those agents
    # are moved under Backend as well.
    state["output"] = (
        "Appointment entities extracted; downstream routing to specific "
        "providers can now be implemented."
    )
    return state
