This folder will contain prompt templates for agents.
