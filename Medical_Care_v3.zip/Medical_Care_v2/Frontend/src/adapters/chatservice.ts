import { ChatBackend, Message } from "../types/chat";

export async function handleUserInput(
  backend: ChatBackend,
  prompt: string,
  attachedFiles: File[] = [],
  signal?: AbortSignal    // ✅ added optional AbortSignal
): Promise<Message> {
  let content = prompt;
  if (attachedFiles.length > 0) {
    content += `\n[Attached: ${attachedFiles.map(f => f.name).join(", ")}]`;
  }

  if (backend.streamMessage && signal) {
    // ✅ streaming mode with Abort support
    let accumulated = "";
    return new Promise((resolve, reject) => {
      backend.streamMessage!(
        content,
        (chunk) => {
          accumulated += chunk;
        },
        (final) => {
          resolve(final || {
            id: Date.now().toString(),
            role: "assistant",
            content: accumulated,
            createdAt: new Date().toISOString(),
          });
        },
        signal
      ).catch(reject);
    });
  } else {
    // ✅ normal mode
    return backend.sendMessage(content);
  }
}

// --- Add workflow API call ---
export async function sendWorkflowMessage(
  patient_id: string,
  symptoms: string,
  preferred_times?: string[]
): Promise<any> {
  const res = await fetch("http://localhost:8000/workflow/triage-plus-appointment", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ patient_id, symptoms, preferred_times }),
  });
  if (!res.ok) throw new Error("Workflow API error");
  return res.json();
}
