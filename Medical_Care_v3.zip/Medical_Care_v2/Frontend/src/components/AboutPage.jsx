// src/components/AboutPage.tsx
import React from "react";

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-5xl mx-auto px-6 py-10">
        <header className="mb-8">
          <h1 className="text-2xl font-semibold text-slate-900">
            About CareFlow e-Hospital
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            AI-Driven Patient Symptom Triage and Follow-up Planner for Healthcare
          </p>
        </header>

        <section className="mb-6 bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-2">
            Overview
          </h2>
          <p className="text-sm text-slate-700 leading-relaxed">
            CareFlow e-Hospital is a prototype platform that demonstrates how
            generative AI can support clinicians and patients in symptom triage
            and follow-up planning. The system simulates integration with
            electronic health records (EHR), symptom questionnaires and medical
            knowledge bases to provide consistent triage suggestions.
          </p>
        </section>

        <section className="mb-6 bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-2">
            What this prototype includes
          </h2>
          <ul className="list-disc list-inside space-y-2 text-sm text-slate-700">
            <li>
              <strong>Clinical login:</strong> entry point for doctors and nurses
              to access the AI triage console.
            </li>
            <li>
              <strong>Patient login:</strong> portal for patients to report
              symptoms and review suggested follow-up steps.
            </li>
            <li>
              <strong>Multi-agent orchestration:</strong> separate agents for
              symptom understanding, risk assessment and plan generation.
            </li>
            <li>
              <strong>Mock EHR data:</strong> synthetic, de-identified records
              used for demonstration only.
            </li>
          </ul>
        </section>

        <section className="mb-6 bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-2">
            Data Privacy & Disclaimer
          </h2>
          <p className="text-sm text-slate-700 leading-relaxed">
            This application is a hackathon prototype and does not provide real
            medical advice. It does not connect to any live hospital systems and
            should not be used for real patients. Any clinical decisions must
            always be taken by qualified healthcare professionals using approved
            hospital tools.
          </p>
        </section>

        <footer className="text-xs text-slate-500">
          © {new Date().getFullYear()} CareFlow e-Hospital — Hackathon prototype.
        </footer>
      </div>
    </div>
  );
};

export default AboutPage;
