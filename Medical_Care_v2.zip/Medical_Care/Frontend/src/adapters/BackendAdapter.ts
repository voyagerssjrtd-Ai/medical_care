// src/adapters/BackendAdapter.ts
import { ChatBackend, Message } from "../types/chat";

const CHAT_API_URL = "http://localhost:8000/chat";
const TRIAGE_API_URL = "http://localhost:8000/triage";

/**
 * Backend adapter for the generic chat + structured triage endpoint.
 *
 * For now the Chat UI still sends a free-text message, but under the hood
 * we call the new /triage endpoint so that the backend can produce
 * normalized triage outputs while remaining backwards compatible.
 */
export const BackendAdapter: ChatBackend = {
  sendMessage: async (content: string): Promise<Message> => {
    // Prefer the new structured /triage endpoint; fall back to /chat if needed.
    let response: Response | null = null;
    let data: any = null;

    try {
      response = await fetch(TRIAGE_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symptoms: content }),
      });

      if (!response.ok) {
        throw new Error(`Triage API error: ${response.status}`);
      }

      data = await response.json();
    } catch (err) {
      // Fallback to legacy /chat behaviour so the UI keeps working even if
      // the new endpoint is misconfigured.
      response = await fetch(CHAT_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: content }),
      });
      data = await response.json();
    }

    let formatted: string;

    // If this looks like the new triage response shape
    if (data && data.follow_up_plan) {
      const triageLevel = data.follow_up_plan.triage_level ?? "unknown";
      const recs: string[] = data.follow_up_plan.recommendations ?? [];

      formatted = [
        `**Triage level:** ${triageLevel}`,
        "",
        "**Recommended actions:**",
        ...recs.map((r) => `- ${r}`),
      ].join("\n");
    }

    // Legacy /chat shape: array (DB rows)
    else if (Array.isArray(data?.response)) {
      formatted =
        "### Results\n\n" +
        data.response
          .map((row: any) =>
            Object.entries(row)
              .map(([k, v]) => `**${k}:** ${v}`)
              .join(" | ")
          )
          .join("\n");
    }

    // Legacy /chat shape: plain string
    else if (typeof data?.response === "string") {
      formatted = data.response;
    }

    // Fallback: pretty-print any JSON
    else {
      formatted = "```json\n" + JSON.stringify(data, null, 2) + "\n```";
    }

    return {
      id: Date.now().toString(),
      role: "assistant",
      content: formatted,
      createdAt: new Date().toISOString(),
    };
  },
};
