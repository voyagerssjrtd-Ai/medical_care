from fastapi import APIRouter

from Backend.app.services.workflow_service import (
    TriageAppointmentRequest,
    TriageAppointmentResponse,
    run_triage_plus_appointment,
)


router = APIRouter(prefix="/workflow", tags=["workflow"])


@router.post("/triage-plus-appointment", response_model=TriageAppointmentResponse)
async def triage_plus_appointment(
    req: TriageAppointmentRequest,
) -> TriageAppointmentResponse:
    """Run triage, guardrails, and appointment suggestion in one step."""

    return run_triage_plus_appointment(req)
