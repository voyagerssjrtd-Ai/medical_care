from typing import Dict, Any
import logging

from Backend.app.models.triage import FollowUpPlan, SymptomTriageResponse
from Backend.agents.chat_agent import chat_query_agent

logger = logging.getLogger(__name__)


def run_triage(symptoms: str, patient_email: str | None = None, additional_context: str | None = None) -> SymptomTriageResponse:
    """Coordinate RAG + EHR context to produce a triage recommendation.

    This function wraps the `chat_query_agent` and converts its rich
    textual output into the normalized SymptomTriageResponse used by the
    HTTP API. For now, EHR and external API usage are minimal and can be
    expanded later.
    """

    logger.info(
        "Starting triage", extra={"symptoms_preview": symptoms[:200], "patient_email": patient_email}
    )

    state: Dict[str, Any] = {"query": symptoms}
    state = chat_query_agent(state)
    raw_output: str = state.get("output", "No response produced")

    # Very lightweight heuristics to derive triage level from the model text
    lowered = raw_output.lower()
    if "emergency" in lowered:
        triage_level = "emergency"
    elif "high" in lowered or "urgent" in lowered:
        triage_level = "high/urgent"
    elif "medium" in lowered:
        triage_level = "medium"
    else:
        triage_level = "low/self-care"

    recommendations: list[str] = []
    for line in raw_output.splitlines():
        stripped = line.strip("-• ")
        if not stripped:
            continue
        if line.lstrip().startswith(("-", "*", "•")):
            recommendations.append(stripped)

    if not recommendations:
        recommendations = [raw_output]

    follow_up_plan = FollowUpPlan(
        triage_level=triage_level,
        recommendations=recommendations,
        follow_up_timeline="See full text for suggested timing.",
        escalation_warning=(
            "If symptoms worsen, new red-flag signs appear, or the patient is worried, "
            "they should seek urgent in-person evaluation."
        ),
    )

    logger.info(
        "Triage completed",
        extra={"triage_level": triage_level, "recommendations_count": len(recommendations)},
    )

    return SymptomTriageResponse(
        summary="AI-generated triage summary.",
        follow_up_plan=follow_up_plan,
        raw_model_output=raw_output,
        intent=state.get("intent"),
        target_agent=state.get("target_agent"),
    )
