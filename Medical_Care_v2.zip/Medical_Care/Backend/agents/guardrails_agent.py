"""Guardrails agent for basic input validation and intent parsing.

This module was moved from the legacy root-level `guardrails.py` so that all
backend logic now lives under the `Backend` package.
"""

from pydantic import BaseModel, Field


class UserQuery(BaseModel):
    query: str = Field(..., min_length=3)
    intent: str = Field(..., description="forecast | reorder | inventory")


FORBIDDEN = ["hack", "illegal", "explode", "virus"]


def validate_input(text: str) -> bool:
    """Validate that the input text does not contain forbidden content.

    Raises a generic Exception when a forbidden term is found. The service
    layer is responsible for catching and turning it into a user-facing
    response.
    """

    lower_text = text.lower()
    for bad in FORBIDDEN:
        if bad in lower_text:
            raise Exception("❌ Forbidden content detected.")
    return True


def parse_intent(user_query: str) -> str:
    """Very simple intent classifier used by the workflow service.

    Currently distinguishes between appointment-related queries and generic
    chat queries.
    """

    q = user_query.lower()
    if "appointment" in q or "book" in q:
        return "appointment"
    return "chat"
