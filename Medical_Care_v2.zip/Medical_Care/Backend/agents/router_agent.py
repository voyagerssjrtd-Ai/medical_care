# Backend/agents/router_agent.py
from pathlib import Path
import yaml
from typing import Dict, Any

# Resolve router_rules.yaml relative to the Backend package root so it works from any CWD
BASE_DIR = Path(__file__).resolve().parents[1]
RULES_PATH = BASE_DIR / "config" / "router_rules.yaml"
RULES = yaml.safe_load(RULES_PATH.read_text(encoding="utf-8"))

def route_query(text: str) -> Dict[str, Any]:
    q = text.lower().strip()

    for rule in RULES["intents"]:
        for kw in rule["keywords"]:
            if kw in q:
                return {
                    "intent": rule["name"],
                    "target_agent": rule["target_agent"],
                    "type": "keyword"
                }

    fb = RULES["fallback"]
    return {
        "intent": fb["name"],
        "target_agent": fb["target_agent"],
        "type": "fallback"
    }
