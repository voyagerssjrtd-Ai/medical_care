# Backend/db/seed_patients.py
import sqlite3
from pathlib import Path

# Correct SQLite DB path
DB_PATH = Path(__file__).resolve().parents[1] / "data" / "inventory.db"

def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Ensure table exists
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            name TEXT,
            age INTEGER,
            gender TEXT,
            mrn TEXT,
            primary_doctor TEXT,
            last_visit TEXT,
            hr INTEGER,
            bp TEXT,
            temp REAL,
            spo2 INTEGER,
            appointment_title TEXT,
            appointment_date TEXT,
            appointment_location TEXT,
            medication1 TEXT,
            medication1_dose TEXT,
            medication1_freq TEXT,
            medication2 TEXT,
            medication2_dose TEXT,
            medication2_freq TEXT,
            active_conditions TEXT,
            plan TEXT,
            next_steps TEXT
        );
        """
    )

    patients = [
        {
            "email": "jasmine@careflow.ai",
            "name": "Jasmine",
            "age": 28,
            "gender": "F",
            "mrn": "MRN-000129",
            "primary_doctor": "Dr. Meera Raman",
            "last_visit": "2025-11-20",
            "hr": 80,
            "bp": "118/74",
            "temp": 36.4,
            "spo2": 99,
            "appointment_title": "OBGYN Consultation",
            "appointment_date": "2025-12-12 10:30 AM",
            "appointment_location": "Fertility Clinic - Room 3",
            "medication1": "Progesterone",
            "medication1_dose": "200 mg",
            "medication1_freq": "Once daily",
            "medication2": "Folic Acid",
            "medication2_dose": "0.5 mg",
            "medication2_freq": "Once daily",
            "active_conditions": "PCOS; Hypothyroid",
            "plan": "Monitor hormones; IUI cycle planned",
            "next_steps": "USG on 30 Nov; clinic review after scan",
        },
        {
            "email": "swetha@careflow.ai",
            "name": "Swetha Renganathan",
            "age": 33,
            "gender": "F",
            "mrn": "MRN-000210",
            "primary_doctor": "Dr. Elizabeth Cristy",
            "last_visit": "2025-11-20",
            "hr": 76,
            "bp": "120/80",
            "temp": 36.6,
            "spo2": 99,
            "appointment_title": "Follow-up Consultation",
            "appointment_date": "2025-12-18 11:00 AM",
            "appointment_location": "OPD – Room 5",
            "medication1": "Metformin",
            "medication1_dose": "500 mg",
            "medication1_freq": "Twice daily",
            "medication2": "Vitamin D",
            "medication2_dose": "1000 IU",
            "medication2_freq": "Once daily",
            "active_conditions": "Type 2 Diabetes; Vitamin D deficiency",
            "plan": "Continue current medications; monitor sugar; diet changes",
            "next_steps": "Lab tests before next visit; follow-up in 6 weeks",
        },
    ]

    for p in patients:
        cur.execute(
            """
            INSERT INTO patients (
                email, name, age, gender, mrn, primary_doctor, last_visit,
                hr, bp, temp, spo2,
                appointment_title, appointment_date, appointment_location,
                medication1, medication1_dose, medication1_freq,
                medication2, medication2_dose, medication2_freq,
                active_conditions, plan, next_steps
            )
            VALUES (
                :email, :name, :age, :gender, :mrn, :primary_doctor, :last_visit,
                :hr, :bp, :temp, :spo2,
                :appointment_title, :appointment_date, :appointment_location,
                :medication1, :medication1_dose, :medication1_freq,
                :medication2, :medication2_dose, :medication2_freq,
                :active_conditions, :plan, :next_steps
            )
            ON CONFLICT(email) DO UPDATE SET
                name=excluded.name,
                age=excluded.age,
                gender=excluded.gender,
                mrn=excluded.mrn,
                primary_doctor=excluded.primary_doctor,
                last_visit=excluded.last_visit,
                hr=excluded.hr,
                bp=excluded.bp,
                temp=excluded.temp,
                spo2=excluded.spo2,
                appointment_title=excluded.appointment_title,
                appointment_date=excluded.appointment_date,
                appointment_location=excluded.appointment_location,
                medication1=excluded.medication1,
                medication1_dose=excluded.medication1_dose,
                medication1_freq=excluded.medication1_freq,
                medication2=excluded.medication2,
                medication2_dose=excluded.medication2_dose,
                medication2_freq=excluded.medication2_freq,
                active_conditions=excluded.active_conditions,
                plan=excluded.plan,
                next_steps=excluded.next_steps;
            """,
            p,
        )

    conn.commit()
    conn.close()
    print("✅ Seeded 2 patient records into patients table")

if __name__ == "__main__":
    main()
